const GAME_WIDTH = 1920;
const GAME_HEIGHT = 1080;
const PLAY_AREA = { x: 60, y: 170, width: 1800, height: 850 };

const DEPTHS = {
  TISSUE_BG: 0,
  FLUID: 2,
  NORMAL_CELL: 20,
  HEALTH_METER: 110,
  DRAGGING_CELL: 220,
  DRAGGING_HEALTH_METER: 230,
  FLOATING_TEXT: 500,
  HUD: 1000,
};

const CELL_KEYS = {
  R: 'R_CELL',
  T: 'T_CELL',
  K: 'K_CELL',
  V: 'VISIBLE_CANCER_CELL',
  H: 'HIDDEN_CANCER_CELL',
};

// The "bad protein" dust cancer cells passively leak needs to read as a
// clearly different kind of particle from the round attack-hit sparks
// (see showDamageReaction), so it's a lumpy, irregular clump instead of
// a plain circle -- baked once as a white shape and tinted per cancer
// type at spawn time (see CancerCell.spawnDustParticle).
const DUST_PROTEIN_TEXTURE_KEY = 'cellTex_dustProtein';

// Extra sensing range (px) added on top of a K-cell's own radius plus
// whatever it's scanning for. A K-cell doesn't need to attach to a
// hidden cancer cell to reveal it -- just getting within this range is
// enough. Shared by the CellManager's actual detection check and by the
// translucent "scanner" ring drawn around every K-cell, so the visual
// always matches the real range.
const K_CELL_DETECTION_BUFFER = 90;

const COLORS = {
  bg: 0x07111f,
  panel: 0x0f2745,
  panelStroke: 0x67e8f9,
  r: 0xff4d4d,
  t: 0xdbeafe,
  k: 0xffffff,
  v: 0x00d4ff,
  h: 0x8b0000,
  green: 0x22c55e,
  yellow: 0xfacc15,
  danger: 0xef4444,
};

// --- Color helpers -----------------------------------------------------
// Cell size/color are configurable per level (see ConfigManager /
// ConfigScene), stored as a '#rrggbb' string (the format an <input
// type="color"> works with) and converted to Phaser's numeric 0xRRGGBB
// form wherever it's actually drawn.
function hexStringToNumber(hex, fallback = 0xffffff) {
  if (typeof hex === 'number') return hex;
  const clean = String(hex || '')
    .replace('#', '')
    .trim();
  const parsed = parseInt(clean, 16);
  return Number.isNaN(parsed) ? fallback : parsed;
}

function numberToHexString(num) {
  const clamped = Math.max(0, Math.min(0xffffff, Math.round(Number(num) || 0)));
  return '#' + clamped.toString(16).padStart(6, '0');
}

function isValidHexColorString(hex) {
  return typeof hex === 'string' && /^#[0-9a-fA-F]{6}$/.test(hex.trim());
}

function darkenColor(colorNum, factor) {
  const r = (colorNum >> 16) & 0xff;
  const g = (colorNum >> 8) & 0xff;
  const b = colorNum & 0xff;
  return (
    (Math.round(r * factor) << 16) |
    (Math.round(g * factor) << 8) |
    Math.round(b * factor)
  );
}

// The original hand-picked rim/shadow tones aren't a uniform "darken" of
// their base color (e.g. K's white body pairs with a light-blue rim, not
// a grey one) -- so when a cell is left at its default color, use the
// original curated rim exactly. Only a genuinely custom color falls back
// to an auto-darkened rim (see resolveRimColor).
const DEFAULT_RIM_COLORS = {
  R_CELL: 0xb91c1c,
  T_CELL: 0x60a5fa,
  K_CELL: 0x93c5fd,
  VISIBLE_CANCER_CELL: 0x0891b2,
  HIDDEN_CANCER_CELL: 0xb91c1c, // disguise rim matches R
};

function resolveRimColor(typeKey, baseColorNum) {
  const defaultBase =
    DEFAULT_CELL_DEFS[typeKey] && DEFAULT_CELL_DEFS[typeKey].color;
  if (baseColorNum === defaultBase) return DEFAULT_RIM_COLORS[typeKey];
  return darkenColor(baseColorNum, 0.62);
}

// Reads a cell type's configured radius/color out of the level config
// (falling back to DEFAULT_CELL_DEFS when absent), in both hex-string
// and numeric form.
function resolveCellAppearance(config, typeKey) {
  const fallbackDef = DEFAULT_CELL_DEFS[typeKey];
  const appearance =
    (config && config.cellAppearance && config.cellAppearance[typeKey]) || {};
  const radius =
    Number(appearance.radius) > 0
      ? Number(appearance.radius)
      : fallbackDef.radius;
  const colorHex = isValidHexColorString(appearance.color)
    ? appearance.color
    : numberToHexString(fallbackDef.color);
  return { radius, colorHex, colorNum: hexStringToNumber(colorHex) };
}

// Cells are animated with non-uniform scale every frame (idle pulse +
// collision "squeeze", roughly 0.75x-1.3x) and briefly up to 1.25x
// during a split. A texture baked 1:1 at rest size would show visible
// softening/pixelation once scaled up. Baking at CELL_TEXTURE_SUPERSAMPLE
// times the logical size (then displaying it back down at the original
// size via baseVisualScale, see Cell below) keeps the jelly effect crisp
// across that whole scale range while costing almost nothing -- there
// are only 6 of these textures at a time, generated once per config.
const CELL_TEXTURE_SUPERSAMPLE = 2;

// Renders a "jelly sphere" cell design (shadow, rim, body, highlights,
// stroke) once into a reusable texture, instead of every Cell instance
// drawing its own Graphics object every time its visual state changes.
// Textures are cached in Phaser's global texture manager (keyed by
// `key`, which encodes radius+color -- see bakeAllCellTextures), so
// calling this again with the same key (same size/color combo) across
// scene restarts is a cheap no-op, and changing size/color in the
// Configurator naturally produces a fresh key instead of stomping the
// old texture.
//
// `spiky: true` adds small triangular nubs around the rim, producing a
// sea-urchin-like silhouette using the exact same colors -- used to
// tell a detected H-cell apart from a true V-cell without touching
// color or adding any text.
function bakeCellTexture(
  scene,
  key,
  radius,
  baseColor,
  rimColor,
  options = {},
) {
  if (scene.textures.exists(key)) return;
  const S = CELL_TEXTURE_SUPERSAMPLE;
  const spiky = !!options.spiky;
  const pad = spiky ? 26 : 14;
  const size = Math.ceil(radius * 2 + pad * 2) * S;
  const cx = size / 2;
  const cy = size / 2;
  const r = radius * S;
  const g = scene.make.graphics({ x: 0, y: 0, add: false });

  if (spiky) {
    // Spikes are drawn first so the smooth body (drawn next) covers
    // their base, leaving only the pointed tips poking past the rim.
    const spikeCount = 11;
    const halfAngle = 0.13;
    const tipDistance = r * 1.22;
    const baseDistance = r * 0.92;
    g.fillStyle(rimColor, 0.95);
    for (let i = 0; i < spikeCount; i++) {
      const angle = (i / spikeCount) * Math.PI * 2;
      const tipX = cx + Math.cos(angle) * tipDistance;
      const tipY = cy + Math.sin(angle) * tipDistance;
      const b1x = cx + Math.cos(angle - halfAngle) * baseDistance;
      const b1y = cy + Math.sin(angle - halfAngle) * baseDistance;
      const b2x = cx + Math.cos(angle + halfAngle) * baseDistance;
      const b2y = cy + Math.sin(angle + halfAngle) * baseDistance;
      g.fillTriangle(tipX, tipY, b1x, b1y, b2x, b2y);
    }
  }

  g.fillStyle(0x000000, 0.18);
  g.fillCircle(cx + 4 * S, cy + 5 * S, r * 1.02);
  g.fillStyle(rimColor, 0.95);
  g.fillCircle(cx, cy, r);
  g.fillStyle(baseColor, 0.92);
  g.fillCircle(cx, cy, r * 0.88);
  g.fillStyle(0xffffff, 0.08);
  g.fillCircle(cx - r * 0.08, cy + r * 0.08, r * 0.62);
  g.fillStyle(0xffffff, 0.28);
  g.fillEllipse(cx - r * 0.35, cy - r * 0.35, r * 0.9, r * 0.45);
  g.fillStyle(0xffffff, 0.18);
  g.fillCircle(cx - r * 0.15, cy - r * 0.15, r * 0.12);
  g.fillStyle(0xffffff, 0.12);
  g.fillCircle(cx + r * 0.24, cy + r * 0.22, r * 0.38);
  g.lineStyle(2 * S, 0xffffff, 0.25);
  g.strokeCircle(cx, cy, r * 0.92);
  g.generateTexture(key, size, size);
  g.destroy();
  // generateTexture() can default a texture to nearest-neighbor
  // filtering depending on renderer/version. Force smooth (bilinear)
  // filtering explicitly so scaling the sprite for the pulse/squeeze
  // animation blends pixels instead of showing hard blocky edges.
  const tex = scene.textures.get(key);
  if (tex && tex.setFilter) tex.setFilter(Phaser.Textures.FilterMode.LINEAR);
}

function bakeDustProteinTexture(scene) {
  if (scene.textures.exists(DUST_PROTEIN_TEXTURE_KEY)) return;
  const size = 22;
  const cx = size / 2;
  const cy = size / 2;
  // A handful of overlapping, unevenly-sized circles reads as a lumpy
  // clump/aggregate rather than a clean single dot -- distinct at a
  // glance from the perfectly round attack-hit particles.
  const lobes = [
    { dx: -3.2, dy: -2.2, r: 4.4 },
    { dx: 3.1, dy: -1.4, r: 3.6 },
    { dx: -1.2, dy: 3.3, r: 4 },
    { dx: 2.6, dy: 2.6, r: 2.9 },
    { dx: 0.2, dy: -0.4, r: 3.2 },
  ];
  const g = scene.make.graphics({ x: 0, y: 0, add: false });
  g.fillStyle(0xffffff, 1);
  lobes.forEach((l) => g.fillCircle(cx + l.dx, cy + l.dy, l.r));
  g.generateTexture(DUST_PROTEIN_TEXTURE_KEY, size, size);
  g.destroy();
  const tex = scene.textures.get(DUST_PROTEIN_TEXTURE_KEY);
  if (tex && tex.setFilter) tex.setFilter(Phaser.Textures.FilterMode.LINEAR);
}

// Bakes (or reuses, if an identical size/color combo was already baked)
// every texture this level's config needs, and returns a lookup table
// of the resulting texture keys. Called once per GameScene start, since
// size/color are per-level config now rather than fixed constants.
function bakeAllCellTextures(scene, config) {
  const appearances = {
    R: resolveCellAppearance(config, CELL_KEYS.R),
    T: resolveCellAppearance(config, CELL_KEYS.T),
    K: resolveCellAppearance(config, CELL_KEYS.K),
    V: resolveCellAppearance(config, CELL_KEYS.V),
    H: resolveCellAppearance(config, CELL_KEYS.H),
  };

  const bake = (typeKey, label, appearance, spiky) => {
    const key =
      'cellTex_' +
      label +
      '_' +
      Math.round(appearance.radius) +
      '_' +
      appearance.colorHex.replace('#', '') +
      (spiky ? '_spiky' : '');
    const rimColor = resolveRimColor(typeKey, appearance.colorNum);
    bakeCellTexture(
      scene,
      key,
      appearance.radius,
      appearance.colorNum,
      rimColor,
      {
        spiky,
      },
    );
    return key;
  };

  const keys = {
    R: bake(CELL_KEYS.R, 'R', appearances.R, false),
    T: bake(CELL_KEYS.T, 'T', appearances.T, false),
    K: bake(CELL_KEYS.K, 'K', appearances.K, false),
    V: bake(CELL_KEYS.V, 'V', appearances.V, false),
    H: bake(CELL_KEYS.H, 'H', appearances.H, false),
    // Detected H keeps H's own configured size but takes on V's
    // configured color, plus the spiky "revealed" silhouette -- same
    // color as V is the whole point (it now reads as visible cancer),
    // the spikes are what still sets it apart from a true V-cell.
    H_DETECTED: bake(
      CELL_KEYS.H,
      'H_detected',
      {
        radius: appearances.H.radius,
        colorHex: appearances.V.colorHex,
        colorNum: appearances.V.colorNum,
      },
      true,
    ),
  };

  bakeDustProteinTexture(scene);
  return keys;
}

const DEFAULT_CELL_DEFS = {
  R_CELL: {
    key: 'R_CELL',
    category: 'healthy',
    label: 'R',
    color: COLORS.r,
    radius: 40,
    maxHealth: 0,
    hitsPerClick: 0,
    lifeTime: 80,
    splitTime: 10,
    impactOnPlayerHealth: 0,
    canDivide: true,
  },
  T_CELL: {
    key: 'T_CELL',
    category: 'healthy',
    label: 'T',
    color: COLORS.t,
    radius: 45,
    maxHealth: 0,
    hitsPerClick: 2,
    lifeTime: 90,
    splitTime: 20,
    impactOnPlayerHealth: 0,
    canDivide: true,
  },
  K_CELL: {
    key: 'K_CELL',
    category: 'healthy',
    label: 'K',
    color: COLORS.k,
    radius: 45,
    maxHealth: 0,
    hitsPerClick: 1,
    lifeTime: 90,
    splitTime: 30,
    impactOnPlayerHealth: 0,
    canDivide: true,
  },
  VISIBLE_CANCER_CELL: {
    key: 'VISIBLE_CANCER_CELL',
    category: 'cancer',
    label: 'V',
    color: COLORS.v,
    radius: 50,
    maxHealth: 100,
    hitsPerClick: 0,
    lifeTime: Infinity,
    splitTime: 30,
    impactOnPlayerHealth: 1,
    canDivide: true,
  },
  HIDDEN_CANCER_CELL: {
    key: 'HIDDEN_CANCER_CELL',
    category: 'cancer',
    label: 'H',
    color: COLORS.r, // disguised as an R-cell until detected
    detectedColor: COLORS.v,
    radius: 50,
    maxHealth: 100,
    hitsPerClick: 0,
    lifeTime: Infinity,
    splitTime: 30,
    impactOnPlayerHealth: 1,
    canDivide: true,
  },
};

class ConfigManager {
  static clone(v) {
    return JSON.parse(JSON.stringify(v));
  }

  static presets = {
    tutorial: {
      id: 'tutorial',
      name: 'Tutorial: Immune Response',
      difficulty: 'Tutorial',
      totalCellsCount: 6,
      totalSurvivalTime: 300,
      totalPlayTime: 300,
      playerHealth: 999,
      playerHealthDangerThresholdPercent: 1,
      maxCells: 20,
      cancerDamageInterval: 999,
      allowCancerCellDragging: false,
      distribution: {
        R_CELL: 34,
        T_CELL: 17,
        K_CELL: 17,
        VISIBLE_CANCER_CELL: 16,
        HIDDEN_CANCER_CELL: 16,
      },
      splitTimes: {
        R_CELL: 999,
        T_CELL: 999,
        K_CELL: 999,
        VISIBLE_CANCER_CELL: 999,
        HIDDEN_CANCER_CELL: 999,
      },
      splitTimeRanges: {
        R_CELL: { min: 999, max: 999 },
        T_CELL: { min: 999, max: 999 },
        K_CELL: { min: 999, max: 999 },
        VISIBLE_CANCER_CELL: { min: 999, max: 999 },
        HIDDEN_CANCER_CELL: { min: 999, max: 999 },
      },
      lifeTimes: { R_CELL: 999, T_CELL: 999, K_CELL: 999 },
      impacts: { VISIBLE_CANCER_CELL: 0, HIDDEN_CANCER_CELL: 0 },
      cellDamage: { T_CELL: 20, K_CELL: 20 },
      damagePerSecond: { T_CELL: 10, K_CELL: 10 },
      cancerHealth: { VISIBLE_CANCER_CELL: 40, HIDDEN_CANCER_CELL: 40 },
    },
    level1: {
      id: 'level1',
      name: 'Level 1: First Response',
      difficulty: 'Easy',
      totalCellsCount: 34,
      totalSurvivalTime: 120,
      totalPlayTime: 120,
      playerHealth: 115,
      playerHealthDangerThresholdPercent: 25,
      maxCells: 115,
      cancerDamageInterval: 6,
      allowCancerCellDragging: true,
      distribution: {
        R_CELL: 60,
        T_CELL: 13,
        K_CELL: 11,
        VISIBLE_CANCER_CELL: 10,
        HIDDEN_CANCER_CELL: 6,
      },
      splitTimes: {
        R_CELL: 18,
        T_CELL: 28,
        K_CELL: 32,
        VISIBLE_CANCER_CELL: 34,
        HIDDEN_CANCER_CELL: 36,
      },
      splitTimeRanges: {
        R_CELL: { min: 15, max: 22 },
        T_CELL: { min: 24, max: 34 },
        K_CELL: { min: 26, max: 38 },
        VISIBLE_CANCER_CELL: { min: 30, max: 42 },
        HIDDEN_CANCER_CELL: { min: 32, max: 46 },
      },
      lifeTimes: { R_CELL: 95, T_CELL: 100, K_CELL: 100 },
      impacts: { VISIBLE_CANCER_CELL: 1, HIDDEN_CANCER_CELL: 1 },
      cellDamage: { T_CELL: 6, K_CELL: 5 },
      damagePerSecond: { T_CELL: 2.4, K_CELL: 2 },
      cancerHealth: { VISIBLE_CANCER_CELL: 130, HIDDEN_CANCER_CELL: 115 },
    },
    level2: {
      id: 'level2',
      name: 'Level 2: Hidden Threats',
      difficulty: 'Medium',
      totalCellsCount: 42,
      totalSurvivalTime: 135,
      totalPlayTime: 135,
      playerHealth: 120,
      playerHealthDangerThresholdPercent: 25,
      maxCells: 135,
      cancerDamageInterval: 5.5,
      allowCancerCellDragging: true,
      distribution: {
        R_CELL: 55,
        T_CELL: 15,
        K_CELL: 12,
        VISIBLE_CANCER_CELL: 10,
        HIDDEN_CANCER_CELL: 8,
      },
      splitTimes: {
        R_CELL: 16,
        T_CELL: 25,
        K_CELL: 29,
        VISIBLE_CANCER_CELL: 31,
        HIDDEN_CANCER_CELL: 32,
      },
      splitTimeRanges: {
        R_CELL: { min: 13, max: 20 },
        T_CELL: { min: 21, max: 31 },
        K_CELL: { min: 23, max: 35 },
        VISIBLE_CANCER_CELL: { min: 25, max: 38 },
        HIDDEN_CANCER_CELL: { min: 26, max: 40 },
      },
      lifeTimes: { R_CELL: 85, T_CELL: 95, K_CELL: 95 },
      impacts: { VISIBLE_CANCER_CELL: 1.1, HIDDEN_CANCER_CELL: 1.25 },
      cellDamage: { T_CELL: 9, K_CELL: 8 },
      damagePerSecond: { T_CELL: 4, K_CELL: 3.4 },
      cancerHealth: { VISIBLE_CANCER_CELL: 135, HIDDEN_CANCER_CELL: 125 },
    },
    level3: {
      id: 'level3',
      name: 'Level 3: Rapid Mutation',
      difficulty: 'Hard',
      totalCellsCount: 48,
      totalSurvivalTime: 150,
      totalPlayTime: 150,
      playerHealth: 135,
      playerHealthDangerThresholdPercent: 20,
      maxCells: 165,
      cancerDamageInterval: 5.5,
      allowCancerCellDragging: true,
      distribution: {
        R_CELL: 50,
        T_CELL: 17,
        K_CELL: 14,
        VISIBLE_CANCER_CELL: 11,
        HIDDEN_CANCER_CELL: 8,
      },
      splitTimes: {
        R_CELL: 15,
        T_CELL: 23,
        K_CELL: 26,
        VISIBLE_CANCER_CELL: 29,
        HIDDEN_CANCER_CELL: 31,
      },
      splitTimeRanges: {
        R_CELL: { min: 12, max: 18 },
        T_CELL: { min: 19, max: 29 },
        K_CELL: { min: 21, max: 32 },
        VISIBLE_CANCER_CELL: { min: 24, max: 36 },
        HIDDEN_CANCER_CELL: { min: 26, max: 39 },
      },
      lifeTimes: { R_CELL: 82, T_CELL: 92, K_CELL: 92 },
      impacts: { VISIBLE_CANCER_CELL: 1.1, HIDDEN_CANCER_CELL: 1.3 },
      cellDamage: { T_CELL: 12, K_CELL: 11 },
      damagePerSecond: { T_CELL: 5.4, K_CELL: 4.8 },
      cancerHealth: { VISIBLE_CANCER_CELL: 155, HIDDEN_CANCER_CELL: 140 },
    },
  };

  static currentConfig = ConfigManager.clone(ConfigManager.presets.level1);

  static loadPreset(id) {
    ConfigManager.currentConfig = ConfigManager.normalizeConfig(
      ConfigManager.clone(
        ConfigManager.presets[id] || ConfigManager.presets.level1,
      ),
    );
    return ConfigManager.currentConfig;
  }

  static saveConfig(c) {
    ConfigManager.currentConfig = ConfigManager.normalizeConfig(
      ConfigManager.clone(c),
    );
    return ConfigManager.currentConfig;
  }

  static getCurrentConfig() {
    return ConfigManager.normalizeConfig(
      ConfigManager.clone(ConfigManager.currentConfig),
    );
  }

  static randomRange(min, max) {
    const safeMin = Number(min);
    const safeMax = Number(max);
    if (Number.isNaN(safeMin) || Number.isNaN(safeMax)) return 1;
    const low = Math.max(0.1, Math.min(safeMin, safeMax));
    const high = Math.max(low, Math.max(safeMin, safeMax));
    return Phaser.Math.FloatBetween(low, high);
  }

  static getSplitRange(key, c) {
    const fallback = Number(
      c.splitTimes && c.splitTimes[key]
        ? c.splitTimes[key]
        : DEFAULT_CELL_DEFS[key].splitTime,
    );
    const saved = c.splitTimeRanges && c.splitTimeRanges[key];
    if (!saved) return { min: fallback, max: fallback };
    const min = Number(saved.min);
    const max = Number(saved.max);
    if (Number.isNaN(min) || Number.isNaN(max))
      return { min: fallback, max: fallback };
    return { min: Math.min(min, max), max: Math.max(min, max) };
  }

  static getCellDef(key, c) {
    const d = ConfigManager.clone(DEFAULT_CELL_DEFS[key]);
    const appearance = resolveCellAppearance(c, key);
    d.radius = appearance.radius;
    d.color = appearance.colorNum;
    d.splitTimeRange = ConfigManager.getSplitRange(key, c);
    d.splitTime = ConfigManager.randomRange(
      d.splitTimeRange.min,
      d.splitTimeRange.max,
    );
    if (d.category === 'healthy') d.lifeTime = Number(c.lifeTimes[key]);
    else d.lifeTime = Infinity;
    if (key === CELL_KEYS.T) d.hitsPerClick = Number(c.cellDamage.T_CELL);
    if (key === CELL_KEYS.K) d.hitsPerClick = Number(c.cellDamage.K_CELL);
    if (key === CELL_KEYS.V || key === CELL_KEYS.H) {
      d.maxHealth = Number(c.cancerHealth[key]);
      d.impactOnPlayerHealth = Number(c.impacts[key]);
    }
    if (key === CELL_KEYS.H) {
      // A detected H-cell should read as "revealed cancer", so it takes
      // on whatever color V is currently configured to, not a fixed
      // default -- matching the H_DETECTED texture baked in
      // bakeAllCellTextures.
      d.detectedColor = resolveCellAppearance(c, CELL_KEYS.V).colorNum;
    }
    return d;
  }

  static distributionToCounts(c) {
    const total = Math.max(1, Math.round(Number(c.totalCellsCount)));
    const rows = Object.entries(c.distribution).map(([key, p]) => {
      const exact = (total * Number(p)) / 100;
      return {
        key,
        floor: Math.floor(exact),
        remainder: exact - Math.floor(exact),
      };
    });
    let used = rows.reduce((s, r) => s + r.floor, 0);
    rows.sort((a, b) => b.remainder - a.remainder);
    let i = 0;
    while (used < total) {
      rows[i % rows.length].floor += 1;
      used += 1;
      i += 1;
    }
    const counts = {};
    rows.forEach((r) => {
      counts[r.key] = r.floor;
    });
    return counts;
  }

  static validate(c) {
    const errors = [];
    const requiredNumbers = [
      ['totalCellsCount', c.totalCellsCount],
      ['totalSurvivalTime', c.totalSurvivalTime],
      ['totalPlayTime', c.totalPlayTime],
      ['playerHealth', c.playerHealth],
      [
        'playerHealthDangerThresholdPercent',
        c.playerHealthDangerThresholdPercent,
      ],
      ['maxCells', c.maxCells],
      ['cancerDamageInterval', c.cancerDamageInterval],
    ];

    [
      'distribution',
      'splitTimes',
      'lifeTimes',
      'impacts',
      'cellDamage',
      'damagePerSecond',
      'cancerHealth',
    ].forEach((g) => {
      Object.keys(c[g] || {}).forEach((k) =>
        requiredNumbers.push([g + '.' + k, c[g][k]]),
      );
    });

    requiredNumbers.forEach(([name, value]) => {
      if (Number.isNaN(Number(value))) errors.push(name + ' must be a number.');
    });

    if (Number(c.totalCellsCount) <= 0)
      errors.push('totalCellsCount must be greater than 0.');
    if (Number(c.totalSurvivalTime) <= 0)
      errors.push('totalSurvivalTime must be greater than 0.');
    if (Number(c.totalPlayTime) <= 0)
      errors.push('totalPlayTime must be greater than 0.');
    if (Number(c.playerHealth) <= 0)
      errors.push('playerHealth must be greater than 0.');
    if (Number(c.maxCells) < Number(c.totalCellsCount))
      errors.push('maxCells must be greater than or equal to totalCellsCount.');
    if (Number(c.cancerDamageInterval) <= 0)
      errors.push('cancerDamageInterval must be greater than 0.');

    const threshold = Number(c.playerHealthDangerThresholdPercent);
    if (threshold < 1 || threshold > 100)
      errors.push('Danger threshold percent must be between 1 and 100.');

    const distTotal = Object.values(c.distribution || {}).reduce(
      (s, v) => s + Number(v),
      0,
    );
    if (Math.abs(distTotal - 100) > 0.001) {
      errors.push(
        'Cell distribution percentage must equal 100. Current total: ' +
          distTotal,
      );
    }

    Object.entries(c.cancerHealth || {}).forEach(([key, value]) => {
      if (Number(value) <= 0)
        errors.push('Cancer health for ' + key + ' must be greater than 0.');
    });

    if (typeof c.allowCancerCellDragging !== 'boolean')
      errors.push('allowCancerCellDragging must be boolean.');
    if (typeof c.winOnAllCancerDestroyed !== 'boolean')
      errors.push('winOnAllCancerDestroyed must be boolean.');

    Object.keys(DEFAULT_CELL_DEFS).forEach((key) => {
      const appearance = (c.cellAppearance && c.cellAppearance[key]) || {};
      if (
        Number.isNaN(Number(appearance.radius)) ||
        Number(appearance.radius) <= 0
      )
        errors.push(
          'cellAppearance.' + key + '.radius must be greater than 0.',
        );
      if (!isValidHexColorString(appearance.color))
        errors.push(
          'cellAppearance.' + key + '.color must be a hex color like #ff4d4d.',
        );
    });

    return { valid: errors.length === 0, errors };
  }

  static getExportPayload() {
    const presets = ConfigManager.clone(ConfigManager.presets);
    return {
      game: 'Cell Defense: Cancer Awareness',
      version: 2,
      exportedAt: new Date().toISOString(),
      presetOrder: ['level1', 'level2', 'level3'],
      presets,
      levels: ['level1', 'level2', 'level3'].map((id) => presets[id]),
      currentConfig: ConfigManager.getCurrentConfig(),
    };
  }

  static normalizeConfig(c) {
    if (!c) return c;
    if (!c.totalPlayTime) c.totalPlayTime = c.totalSurvivalTime || 120;
    if (!c.totalSurvivalTime) c.totalSurvivalTime = c.totalPlayTime;
    if (typeof c.winOnAllCancerDestroyed !== 'boolean')
      c.winOnAllCancerDestroyed = true;
    if (c.lifeTimes) {
      delete c.lifeTimes.VISIBLE_CANCER_CELL;
      delete c.lifeTimes.HIDDEN_CANCER_CELL;
    }
    if (!c.damagePerSecond)
      c.damagePerSecond = ConfigManager.clone(
        c.cellDamage || { T_CELL: 2, K_CELL: 1 },
      );
    if (!c.splitTimeRanges) c.splitTimeRanges = {};
    Object.keys(DEFAULT_CELL_DEFS).forEach((key) => {
      if (!c.splitTimeRanges[key]) {
        const split = Number(
          c.splitTimes && c.splitTimes[key]
            ? c.splitTimes[key]
            : DEFAULT_CELL_DEFS[key].splitTime,
        );
        c.splitTimeRanges[key] = { min: split, max: split };
      }
    });
    if (!c.cellAppearance) c.cellAppearance = {};
    Object.keys(DEFAULT_CELL_DEFS).forEach((key) => {
      const existing = c.cellAppearance[key] || {};
      const fallbackDef = DEFAULT_CELL_DEFS[key];
      c.cellAppearance[key] = {
        radius:
          Number(existing.radius) > 0
            ? Number(existing.radius)
            : fallbackDef.radius,
        color: isValidHexColorString(existing.color)
          ? existing.color
          : numberToHexString(fallbackDef.color),
      };
    });
    return c;
  }

  static extractImportedPresets(jsonData) {
    if (!jsonData || typeof jsonData !== 'object') return null;
    if (jsonData.presets && typeof jsonData.presets === 'object')
      return jsonData.presets;
    if (Array.isArray(jsonData.levels)) {
      const mapped = {};
      jsonData.levels.slice(0, 3).forEach((level, index) => {
        mapped['level' + (index + 1)] = level;
      });
      return mapped;
    }
    if (jsonData.level1 || jsonData.level2 || jsonData.level3) {
      return {
        level1: jsonData.level1,
        level2: jsonData.level2,
        level3: jsonData.level3,
      };
    }
    return null;
  }

  static importLevelsFromJson(jsonData) {
    const importedPresets = ConfigManager.extractImportedPresets(jsonData);
    if (!importedPresets) {
      return {
        valid: false,
        errors: [
          'JSON must contain presets, levels, or level1/level2/level3 objects.',
        ],
      };
    }

    const requiredIds = ['level1', 'level2', 'level3'];
    const errors = [];
    const nextPresets = {};

    requiredIds.forEach((id) => {
      if (!importedPresets[id]) {
        errors.push('Missing preset: ' + id);
        return;
      }
      const preset = ConfigManager.normalizeConfig(
        ConfigManager.clone(importedPresets[id]),
      );
      preset.id = id;
      preset.name = preset.name || id;
      preset.difficulty = preset.difficulty || 'Custom';
      const result = ConfigManager.validate(preset);
      if (!result.valid)
        errors.push(id + ' validation errors:\n' + result.errors.join('\n'));
      else nextPresets[id] = preset;
    });

    if (errors.length) return { valid: false, errors };
    ConfigManager.presets = ConfigManager.clone(nextPresets);
    ConfigManager.currentConfig = ConfigManager.clone(
      ConfigManager.presets.level1,
    );
    return { valid: true, errors: [] };
  }
}

class BootScene extends Phaser.Scene {
  constructor() {
    super('BootScene');
  }
  create() {
    this.scene.start('ConfigScene');
  }
}

class ConfigScene extends Phaser.Scene {
  constructor() {
    super('ConfigScene');
    this.domElement = null;
    this.bound = [];
    this.levelsFileInput = null;
  }

  create() {
    this.add.rectangle(0, 0, GAME_WIDTH, GAME_HEIGHT, COLORS.bg).setOrigin(0);
    this.add
      .text(960, 54, 'Cell Defense: Cancer Awareness', {
        fontFamily: 'Arial',
        fontSize: '48px',
        color: '#67e8f9',
        fontStyle: 'bold',
      })
      .setOrigin(0.5);
    this.add
      .text(
        960,
        105,
        'Cancer cells remain alive until destroyed. Adjust level balance and play time below.',
        {
          fontFamily: 'Arial',
          fontSize: '24px',
          color: '#cbd5e1',
        },
      )
      .setOrigin(0.5);
    this.createPanel(ConfigManager.getCurrentConfig());
    this.events.once(Phaser.Scenes.Events.SHUTDOWN, this.cleanUp, this);
  }

  field(id, label, value, type = 'number') {
    const step = type === 'number' ? 'step="0.01"' : '';
    return `<div class="cd-field"><label for="${id}">${label}</label><input id="${id}" type="${type}" ${step} value="${value}" /></div>`;
  }

  selectBool(id, label, value) {
    return `<div class="cd-field"><label for="${id}">${label}</label><select id="${id}"><option value="true" ${value ? 'selected' : ''}>true</option><option value="false" ${!value ? 'selected' : ''}>false</option></select></div>`;
  }

  section(title, html, help = '') {
    return `<div class="cd-section"><h2>${title}</h2><div class="cd-grid">${html}</div>${help ? `<div class="cd-help">${help}</div>` : ''}</div>`;
  }

  panelHTML(c) {
    const d = c.distribution;
    const life = c.lifeTimes;
    const impacts = c.impacts;
    const damage = c.cellDamage;
    const dps = c.damagePerSecond || c.cellDamage;
    const ranges = c.splitTimeRanges;
    const health = c.cancerHealth;
    const appearance = c.cellAppearance;

    return `<div class="cd-panel"><h1>Configurator</h1><p>Edit level balance. Use Total Play Time Allowed for the actual timer.</p><div class="cd-actions"><button class="cd-btn secondary" id="load-tutorial">Load Tutorial</button><button class="cd-btn secondary" id="load-level1">Load Level 1</button><button class="cd-btn secondary" id="load-level2">Load Level 2</button><button class="cd-btn secondary" id="load-level3">Load Level 3</button></div>${this.section('Level Settings', this.field('levelName', 'Level Name', c.name, 'text') + this.field('totalCellsCount', 'Total Cells Count', c.totalCellsCount) + this.field('totalPlayTime', 'Total Play Time Allowed Seconds', c.totalPlayTime || c.totalSurvivalTime) + this.field('totalSurvivalTime', 'Survival Time Seconds', c.totalSurvivalTime) + this.field('playerHealth', 'Player Health', c.playerHealth) + this.field('playerHealthDangerThresholdPercent', 'Danger Threshold Percent', c.playerHealthDangerThresholdPercent) + this.field('maxCells', 'Max Cells', c.maxCells) + this.field('cancerDamageInterval', 'Cancer Damage Interval', c.cancerDamageInterval) + this.selectBool('allowCancerCellDragging', 'Allow Cancer Cell Dragging', c.allowCancerCellDragging) + this.selectBool('winOnAllCancerDestroyed', 'Win If All Cancer Destroyed Early', c.winOnAllCancerDestroyed))}${this.section('Cell Appearance (Size & Color)', this.field('appearance_radius_R_CELL', 'R-Cell Radius', appearance.R_CELL.radius) + this.field('appearance_color_R_CELL', 'R-Cell Color', appearance.R_CELL.color, 'color') + this.field('appearance_radius_T_CELL', 'T-Cell Radius', appearance.T_CELL.radius) + this.field('appearance_color_T_CELL', 'T-Cell Color', appearance.T_CELL.color, 'color') + this.field('appearance_radius_K_CELL', 'K-Cell Radius', appearance.K_CELL.radius) + this.field('appearance_color_K_CELL', 'K-Cell Color', appearance.K_CELL.color, 'color') + this.field('appearance_radius_VISIBLE_CANCER_CELL', 'Visible Cancer Radius', appearance.VISIBLE_CANCER_CELL.radius) + this.field('appearance_color_VISIBLE_CANCER_CELL', 'Visible Cancer Color', appearance.VISIBLE_CANCER_CELL.color, 'color') + this.field('appearance_radius_HIDDEN_CANCER_CELL', 'Hidden Cancer Radius', appearance.HIDDEN_CANCER_CELL.radius) + this.field('appearance_color_HIDDEN_CANCER_CELL', 'Hidden Cancer Color (disguise)', appearance.HIDDEN_CANCER_CELL.color, 'color'), 'Hidden Cancer color is only its disguise before detection -- once detected it always switches to the Visible Cancer color above, plus a spiky outline, regardless of this setting.')}${this.section('Cell Distribution Percentages', this.field('dist_R_CELL', 'R-Cells Percent', d.R_CELL) + this.field('dist_T_CELL', 'T-Cells Percent', d.T_CELL) + this.field('dist_K_CELL', 'K-Cells Percent', d.K_CELL) + this.field('dist_VISIBLE_CANCER_CELL', 'Visible Cancer Percent', d.VISIBLE_CANCER_CELL) + this.field('dist_HIDDEN_CANCER_CELL', 'Hidden Cancer Percent', d.HIDDEN_CANCER_CELL), 'R + T + K + Visible Cancer + Hidden Cancer must equal 100.')}${this.section('Immune Cell Damage', this.field('damage_T_CELL', 'T-Cell Hits Per Click', damage.T_CELL) + this.field('damage_K_CELL', 'K-Cell Hits Per Click', damage.K_CELL))}${this.section('Auto Attack Damage Per Second', this.field('dps_T_CELL', 'T-Cell Damage Per Second', dps.T_CELL) + this.field('dps_K_CELL', 'K-Cell Damage Per Second', dps.K_CELL))}${this.section('Cancer Cell Health', this.field('health_VISIBLE_CANCER_CELL', 'Visible Cancer Health', health.VISIBLE_CANCER_CELL) + this.field('health_HIDDEN_CANCER_CELL', 'Hidden Cancer Health', health.HIDDEN_CANCER_CELL))}${this.section('Split Time Range Seconds', this.field('splitMin_R_CELL', 'R Split Min', ranges.R_CELL.min) + this.field('splitMax_R_CELL', 'R Split Max', ranges.R_CELL.max) + this.field('splitMin_T_CELL', 'T Split Min', ranges.T_CELL.min) + this.field('splitMax_T_CELL', 'T Split Max', ranges.T_CELL.max) + this.field('splitMin_K_CELL', 'K Split Min', ranges.K_CELL.min) + this.field('splitMax_K_CELL', 'K Split Max', ranges.K_CELL.max) + this.field('splitMin_VISIBLE_CANCER_CELL', 'Visible Cancer Split Min', ranges.VISIBLE_CANCER_CELL.min) + this.field('splitMax_VISIBLE_CANCER_CELL', 'Visible Cancer Split Max', ranges.VISIBLE_CANCER_CELL.max) + this.field('splitMin_HIDDEN_CANCER_CELL', 'Hidden Cancer Split Min', ranges.HIDDEN_CANCER_CELL.min) + this.field('splitMax_HIDDEN_CANCER_CELL', 'Hidden Cancer Split Max', ranges.HIDDEN_CANCER_CELL.max))}${this.section('Healthy Cell Life Times Seconds', this.field('life_R_CELL', 'R Life Time', life.R_CELL) + this.field('life_T_CELL', 'T Life Time', life.T_CELL) + this.field('life_K_CELL', 'K Life Time', life.K_CELL), 'Cancer cells do not have lifetime.')}${this.section('Cancer Impact On Player Health', this.field('impact_VISIBLE_CANCER_CELL', 'Visible Cancer Impact', impacts.VISIBLE_CANCER_CELL) + this.field('impact_HIDDEN_CANCER_CELL', 'Hidden Cancer Impact', impacts.HIDDEN_CANCER_CELL))}<div class="cd-actions"><button class="cd-btn" id="save-config">Save Config</button><button class="cd-btn" id="start-game">Start Game</button><button class="cd-btn secondary" id="level-select">Go To Level Select</button><button class="cd-btn secondary" id="export-levels-json">Export Levels JSON</button><button class="cd-btn secondary" id="load-levels-json">Load Levels JSON</button></div><div class="cd-error" id="error-box"></div><div class="cd-success" id="success-box">Config saved successfully.</div></div>`;
  }

  createPanel(c) {
    if (this.domElement) this.domElement.destroy();
    this.domElement = this.add.dom(960, 575).createFromHTML(this.panelHTML(c));
    this.addEvents();
  }

  bind(id, fn, eventName = 'click') {
    const el = this.domElement.node.querySelector('#' + id);
    if (!el) return;
    el.addEventListener(eventName, fn);
    this.bound.push({ el, fn, eventName });
  }

  addEvents() {
    this.bind('load-tutorial', () =>
      this.createPanel(ConfigManager.loadPreset('tutorial')),
    );
    this.bind('load-level1', () =>
      this.createPanel(ConfigManager.loadPreset('level1')),
    );
    this.bind('load-level2', () =>
      this.createPanel(ConfigManager.loadPreset('level2')),
    );
    this.bind('load-level3', () =>
      this.createPanel(ConfigManager.loadPreset('level3')),
    );
    this.bind('save-config', () => this.save(false));
    this.bind('start-game', () => {
      if (this.save(true))
        this.scene.start('GameScene', {
          config: ConfigManager.getCurrentConfig(),
        });
    });
    this.bind('level-select', () => {
      if (this.save(true)) this.scene.start('LevelSelectScene');
    });
    this.bind('export-levels-json', () => this.exportLevelsJson());
    this.bind('load-levels-json', () => this.openLevelsJsonPicker());
  }

  read() {
    const root = this.domElement.node;
    const value = (id) => root.querySelector('#' + id).value;
    const number = (id) => Number(value(id));
    const base = ConfigManager.getCurrentConfig();
    return {
      id: base.id || 'custom',
      name: value('levelName') || 'Custom Level',
      difficulty: base.difficulty || 'Custom',
      totalCellsCount: number('totalCellsCount'),
      totalSurvivalTime: number('totalSurvivalTime'),
      totalPlayTime: number('totalPlayTime'),
      playerHealth: number('playerHealth'),
      playerHealthDangerThresholdPercent: number(
        'playerHealthDangerThresholdPercent',
      ),
      maxCells: number('maxCells'),
      cancerDamageInterval: number('cancerDamageInterval'),
      allowCancerCellDragging: value('allowCancerCellDragging') === 'true',
      winOnAllCancerDestroyed: value('winOnAllCancerDestroyed') === 'true',
      cellAppearance: {
        R_CELL: {
          radius: number('appearance_radius_R_CELL'),
          color: value('appearance_color_R_CELL'),
        },
        T_CELL: {
          radius: number('appearance_radius_T_CELL'),
          color: value('appearance_color_T_CELL'),
        },
        K_CELL: {
          radius: number('appearance_radius_K_CELL'),
          color: value('appearance_color_K_CELL'),
        },
        VISIBLE_CANCER_CELL: {
          radius: number('appearance_radius_VISIBLE_CANCER_CELL'),
          color: value('appearance_color_VISIBLE_CANCER_CELL'),
        },
        HIDDEN_CANCER_CELL: {
          radius: number('appearance_radius_HIDDEN_CANCER_CELL'),
          color: value('appearance_color_HIDDEN_CANCER_CELL'),
        },
      },
      distribution: {
        R_CELL: number('dist_R_CELL'),
        T_CELL: number('dist_T_CELL'),
        K_CELL: number('dist_K_CELL'),
        VISIBLE_CANCER_CELL: number('dist_VISIBLE_CANCER_CELL'),
        HIDDEN_CANCER_CELL: number('dist_HIDDEN_CANCER_CELL'),
      },
      cellDamage: {
        T_CELL: number('damage_T_CELL'),
        K_CELL: number('damage_K_CELL'),
      },
      damagePerSecond: {
        T_CELL: number('dps_T_CELL'),
        K_CELL: number('dps_K_CELL'),
      },
      cancerHealth: {
        VISIBLE_CANCER_CELL: number('health_VISIBLE_CANCER_CELL'),
        HIDDEN_CANCER_CELL: number('health_HIDDEN_CANCER_CELL'),
      },
      splitTimes: {
        R_CELL: number('splitMin_R_CELL'),
        T_CELL: number('splitMin_T_CELL'),
        K_CELL: number('splitMin_K_CELL'),
        VISIBLE_CANCER_CELL: number('splitMin_VISIBLE_CANCER_CELL'),
        HIDDEN_CANCER_CELL: number('splitMin_HIDDEN_CANCER_CELL'),
      },
      splitTimeRanges: {
        R_CELL: {
          min: number('splitMin_R_CELL'),
          max: number('splitMax_R_CELL'),
        },
        T_CELL: {
          min: number('splitMin_T_CELL'),
          max: number('splitMax_T_CELL'),
        },
        K_CELL: {
          min: number('splitMin_K_CELL'),
          max: number('splitMax_K_CELL'),
        },
        VISIBLE_CANCER_CELL: {
          min: number('splitMin_VISIBLE_CANCER_CELL'),
          max: number('splitMax_VISIBLE_CANCER_CELL'),
        },
        HIDDEN_CANCER_CELL: {
          min: number('splitMin_HIDDEN_CANCER_CELL'),
          max: number('splitMax_HIDDEN_CANCER_CELL'),
        },
      },
      lifeTimes: {
        R_CELL: number('life_R_CELL'),
        T_CELL: number('life_T_CELL'),
        K_CELL: number('life_K_CELL'),
      },
      impacts: {
        VISIBLE_CANCER_CELL: number('impact_VISIBLE_CANCER_CELL'),
        HIDDEN_CANCER_CELL: number('impact_HIDDEN_CANCER_CELL'),
      },
    };
  }

  save(silent) {
    const c = this.read();
    const r = ConfigManager.validate(c);
    if (!r.valid) {
      this.showErrorMessage(r.errors.join('\n'));
      return false;
    }
    ConfigManager.saveConfig(c);
    if (!silent) this.showSuccessMessage('Config saved successfully.');
    return true;
  }

  exportLevelsJson() {
    if (!this.save(true)) return;
    const blob = new Blob(
      [JSON.stringify(ConfigManager.getExportPayload(), null, 2)],
      { type: 'application/json;charset=utf-8' },
    );
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download =
      'cell-defense-level-presets-' +
      new Date().toISOString().slice(0, 10) +
      '.json';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(() => URL.revokeObjectURL(url), 0);
    this.showSuccessMessage('Level presets exported successfully as JSON.');
  }

  ensureLevelsFileInput() {
    if (this.levelsFileInput) return this.levelsFileInput;
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'application/json,.json';
    input.style.position = 'fixed';
    input.style.left = '-9999px';
    input.addEventListener('change', (e) => this.loadLevelsJsonFile(e));
    document.body.appendChild(input);
    this.levelsFileInput = input;
    return input;
  }

  openLevelsJsonPicker() {
    const input = this.ensureLevelsFileInput();
    input.value = '';
    input.click();
  }

  loadLevelsJsonFile(e) {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const result = ConfigManager.importLevelsFromJson(
          JSON.parse(reader.result),
        );
        if (!result.valid) {
          this.showErrorMessage(result.errors.join('\n\n'));
          return;
        }
        this.createPanel(ConfigManager.getCurrentConfig());
        this.time.delayedCall(60, () =>
          this.showSuccessMessage('Level presets loaded successfully.'),
        );
      } catch (err) {
        this.showErrorMessage('Could not parse JSON file.\n' + err.message);
      }
    };
    reader.readAsText(file);
  }

  showErrorMessage(message) {
    if (!this.domElement) return;
    const err = this.domElement.node.querySelector('#error-box');
    const ok = this.domElement.node.querySelector('#success-box');
    if (ok) ok.style.display = 'none';
    if (err) {
      err.textContent = message;
      err.style.display = 'block';
    }
  }

  showSuccessMessage(message) {
    if (!this.domElement) return;
    const err = this.domElement.node.querySelector('#error-box');
    const ok = this.domElement.node.querySelector('#success-box');
    if (err) err.style.display = 'none';
    if (ok) {
      ok.textContent = message;
      ok.style.display = 'block';
    }
  }

  cleanUp() {
    this.bound.forEach(({ el, fn, eventName }) =>
      el.removeEventListener(eventName, fn),
    );
    this.bound = [];
    if (this.domElement) this.domElement.destroy();
    this.domElement = null;
    if (this.levelsFileInput) this.levelsFileInput.remove();
    this.levelsFileInput = null;
  }
}

class LevelSelectScene extends Phaser.Scene {
  constructor() {
    super('LevelSelectScene');
  }

  create() {
    this.add.rectangle(0, 0, GAME_WIDTH, GAME_HEIGHT, COLORS.bg).setOrigin(0);
    this.add
      .text(960, 115, 'Choose Level Preset', {
        fontFamily: 'Arial',
        fontSize: '60px',
        color: '#67e8f9',
        fontStyle: 'bold',
      })
      .setOrigin(0.5);

    [
      ConfigManager.presets.tutorial,
      ConfigManager.presets.level1,
      ConfigManager.presets.level2,
      ConfigManager.presets.level3,
    ].forEach((p, i) => {
      this.card(270 + i * 460, 520, p);
    });

    this.button(960, 880, 'Back To Configurator', 390, 72, () =>
      this.scene.start('ConfigScene'),
    );
  }

  card(x, y, p) {
    this.add
      .rectangle(x, y, 440, 500, COLORS.panel, 0.92)
      .setStrokeStyle(3, COLORS.panelStroke);
    this.add
      .text(x, y - 180, p.name, {
        fontFamily: 'Arial',
        fontSize: '30px',
        color: '#fff',
        fontStyle: 'bold',
        align: 'center',
        wordWrap: { width: 390 },
      })
      .setOrigin(0.5);
    this.add
      .text(x, y - 105, p.difficulty, {
        fontFamily: 'Arial',
        fontSize: '25px',
        color: '#facc15',
        fontStyle: 'bold',
      })
      .setOrigin(0.5);
    const info = [
      'Cells: ' + p.totalCellsCount,
      'Play Time: ' + (p.totalPlayTime || p.totalSurvivalTime) + 's',
      'T Hit: ' + p.cellDamage.T_CELL,
      'K Hit: ' + p.cellDamage.K_CELL,
      'V Health: ' + p.cancerHealth.VISIBLE_CANCER_CELL,
      'H Health: ' + p.cancerHealth.HIDDEN_CANCER_CELL,
    ].join('\n');
    this.add
      .text(x, y + 15, info, {
        fontFamily: 'Arial',
        fontSize: '24px',
        color: '#cbd5e1',
        align: 'center',
        lineSpacing: 9,
      })
      .setOrigin(0.5);
    this.button(x, y + 188, 'Play ' + p.difficulty, 250, 66, () => {
      ConfigManager.loadPreset(p.id);
      this.scene.start('GameScene', {
        config: ConfigManager.getCurrentConfig(),
      });
    });
  }

  button(x, y, label, w, h, cb) {
    const rect = this.add
      .rectangle(x, y, w, h, 0x22c55e)
      .setStrokeStyle(3, 0xbbf7d0)
      .setInteractive({ useHandCursor: true });
    this.add
      .text(x, y, label, {
        fontFamily: 'Arial',
        fontSize: '25px',
        color: '#052e16',
        fontStyle: 'bold',
      })
      .setOrigin(0.5);
    rect.on('pointerover', () => rect.setFillStyle(0x67e8f9));
    rect.on('pointerout', () => rect.setFillStyle(0x22c55e));
    rect.on('pointerdown', cb);
  }
}

class Cell extends Phaser.GameObjects.Container {
  constructor(scene, x, y, def, config) {
    super(scene, x, y);
    this.scene = scene;
    this.config = config;
    this.id = Phaser.Utils.String.UUID();
    this.key = def.key;
    this.category = def.category;
    this.label = def.label;
    this.radius = def.radius;
    this.currentColor = def.color;
    this.health = def.maxHealth;
    this.maxHealth = def.maxHealth;
    this.hitsPerClick = def.hitsPerClick;
    this.splitTimeRange = def.splitTimeRange || {
      min: def.splitTime,
      max: def.splitTime,
    };
    this.splitTime = def.splitTime;
    this.lifeTime = def.lifeTime;
    this.age = 0;
    this.lastSplitAt = 0;
    this.isAlive = true;
    this.canDivide = def.canDivide;
    this.isDragging = false;
    this.dragStarted = false;
    this.dragThreshold = 8;
    this.suppressClickUntil = 0;
    this.attachedTo = null;
    this.attachedOffset = { x: 0, y: 0 };
    this.homeX = x;
    this.homeY = y;
    this.floatPhase = Phaser.Math.FloatBetween(0, Math.PI * 2);
    this.floatSpeed = Phaser.Math.FloatBetween(0.55, 1.15);
    this.floatRadiusX =
      this.category === 'cancer'
        ? Phaser.Math.FloatBetween(1, 3)
        : Phaser.Math.FloatBetween(4, 12);
    this.floatRadiusY =
      this.category === 'cancer'
        ? Phaser.Math.FloatBetween(1, 3)
        : Phaser.Math.FloatBetween(3, 10);
    this.squeezeX = 1;
    this.squeezeY = 1;
    this.squeezeRecoverSpeed = 8;

    this.cellGraphics = scene.add.image(
      0,
      0,
      this.getTextureKeyForCurrentState(),
    );
    // Texture pixels are CELL_TEXTURE_SUPERSAMPLE times bigger than the
    // logical cell size (see bakeCellTexture), so scale back down to
    // display at the intended size. All later scaling (idle pulse,
    // collision squeeze) multiplies on top of this base scale rather
    // than overwriting it, so the extra resolution is preserved.
    this.baseVisualScale = 1 / CELL_TEXTURE_SUPERSAMPLE;
    this.cellGraphics.setScale(this.baseVisualScale);
    this.bodyCircle = scene.add.circle(0, 0, this.radius + 6, 0xffffff, 0.001);

    // K-cells and T-cells read as similar light blue/white shades, but
    // only K-cells can sense hidden cancer cells at range. A soft,
    // translucent "scanner" ring makes that ability visible and gives
    // players an unambiguous way to tell the two apart at a glance.
    this.detectionRing = null;
    if (this.key === CELL_KEYS.K) {
      const ringRadius = this.radius + K_CELL_DETECTION_BUFFER;
      this.detectionRing = scene.add.circle(0, 0, ringRadius, 0x67e8f9, 0.05);
      this.detectionRing.setStrokeStyle(2, 0x67e8f9, 0.4);
      this.detectionRingTween = scene.tweens.add({
        targets: this.detectionRing,
        alpha: 0.15,
        duration: 1100,
        yoyo: true,
        repeat: -1,
        ease: 'Sine.easeInOut',
      });
    }

    this.healthBarBg = scene.add
      .rectangle(0, 0, this.radius * 2.2, 8, 0x1e293b, 0.9)
      .setVisible(false);
    this.healthBarFill = scene.add
      .rectangle(
        -this.radius * 1.1,
        0,
        this.radius * 2.2,
        8,
        COLORS.green,
        0.95,
      )
      .setOrigin(0, 0.5)
      .setVisible(false);
    this.healthBarContainer = scene.add.container(
      this.x,
      this.y - this.radius - 16,
      [this.healthBarBg, this.healthBarFill],
    );
    this.healthBarContainer.setDepth(DEPTHS.HEALTH_METER).setVisible(false);

    const children = this.detectionRing
      ? [this.detectionRing, this.cellGraphics, this.bodyCircle]
      : [this.cellGraphics, this.bodyCircle];
    this.add(children);
    scene.add.existing(this);
    this.setDepth(DEPTHS.NORMAL_CELL);
    this.redrawCellVisual();
    this.enableDragging(scene);
  }

  enableDragging(scene) {
    this.bodyCircle.setInteractive({ useHandCursor: true });
    scene.input.setDraggable(this.bodyCircle);
    this.bodyCircle.on('dragstart', (p) => {
      if (!this.isAlive || scene.isFinished) return;
      if (
        this.category === 'cancer' &&
        !(scene.configData || {}).allowCancerCellDragging
      )
        return;
      this.dragStarted = false;
      this.isDragging = true;
      this.dragStartX = this.x;
      this.dragStartY = this.y;
      this.dragStartHomeX = this.homeX;
      this.dragStartHomeY = this.homeY;
      this.pointerStartX = p.worldX;
      this.pointerStartY = p.worldY;
    });
    this.bodyCircle.on('drag', (p) => {
      if (!this.isAlive || scene.isFinished || !this.isDragging) return;
      const dist = Phaser.Math.Distance.Between(
        this.pointerStartX,
        this.pointerStartY,
        p.worldX,
        p.worldY,
      );
      if (!this.dragStarted && dist < this.dragThreshold) return;
      if (!this.dragStarted) {
        this.dragStarted = true;
        if (this.category === 'healthy' && scene.cellManager)
          scene.cellManager.detachHealthyCell(this, false);
        this.setDraggingDepth(true);
      }
      this.x = Phaser.Math.Clamp(
        p.worldX,
        PLAY_AREA.x + this.radius,
        PLAY_AREA.x + PLAY_AREA.width - this.radius,
      );
      this.y = Phaser.Math.Clamp(
        p.worldY,
        PLAY_AREA.y + this.radius,
        PLAY_AREA.y + PLAY_AREA.height - this.radius,
      );
      this.homeX = this.x;
      this.homeY = this.y;
      if (
        this.category === 'cancer' &&
        this.attachedCells &&
        this.attachedCells.size > 0
      )
        scene.cellManager.rebuildCancerAttachments(this);
      this.syncHealthMeterPosition();
    });
    this.bodyCircle.on('dragend', () => {
      if (!this.isDragging) return;
      this.isDragging = false;
      this.setDraggingDepth(false);
      if (!this.dragStarted) {
        this.x = this.dragStartX;
        this.y = this.dragStartY;
        this.homeX = this.dragStartHomeX;
        this.homeY = this.dragStartHomeY;
        this.syncHealthMeterPosition();
        return;
      }
      this.suppressClickUntil = scene.time.now + 160;
      if (this.category === 'healthy') {
        const attached =
          scene.cellManager.attachHealthyCellToNearestCancer(this);
        if (!attached) {
          this.setHomePosition(this.x, this.y);
          scene.showFloatingText(
            this.x,
            this.y - this.radius - 24,
            'Not attached',
            '#fecaca',
          );
        }
      } else {
        if (this.attachedCells)
          scene.cellManager.rebuildCancerAttachments(this);
        this.setHomePosition(this.x, this.y);
      }
      this.dragStarted = false;
    });
  }

  updateCell(dt) {
    if (!this.isAlive) return;
    this.age += dt;
    if (this.attachedTo) {
      if (!this.attachedTo.isAlive)
        this.scene.cellManager.detachHealthyCell(this, true);
      else {
        this.x = this.attachedTo.x + this.attachedOffset.x;
        this.y = this.attachedTo.y + this.attachedOffset.y;
      }
    } else if (!this.isDragging) {
      this.idleFloat();
      this.checkBounds();
    }
    const recover = Math.min(1, dt * this.squeezeRecoverSpeed);
    this.squeezeX += (1 - this.squeezeX) * recover;
    this.squeezeY += (1 - this.squeezeY) * recover;
    const pulse = 1 + Math.sin(this.age * 2.5 + this.floatPhase) * 0.04;
    this.cellGraphics.setScale(
      this.baseVisualScale * pulse * this.squeezeX,
      this.baseVisualScale * pulse * this.squeezeY,
    );
    this.syncHealthMeterPosition();
    this.syncHealthMeterDepth();
    if (
      this.category === 'healthy' &&
      this.config.id !== 'tutorial' &&
      this.age >= this.lifeTime
    )
      this.die();
  }

  idleFloat() {
    const t = this.age * this.floatSpeed + this.floatPhase;
    this.x = this.homeX + Math.cos(t) * this.floatRadiusX;
    this.y = this.homeY + Math.sin(t * 1.18) * this.floatRadiusY;
  }

  applyCollisionSqueeze(nx, ny, overlap) {
    const strength = Phaser.Math.Clamp(overlap / this.radius, 0.04, 0.22);
    if (Math.abs(nx) > Math.abs(ny)) {
      this.squeezeX = Math.min(this.squeezeX, 1 - strength);
      this.squeezeY = Math.max(this.squeezeY, 1 + strength * 0.65);
    } else {
      this.squeezeX = Math.max(this.squeezeX, 1 + strength * 0.65);
      this.squeezeY = Math.min(this.squeezeY, 1 - strength);
    }
  }

  setHomePosition(x, y) {
    this.homeX = Phaser.Math.Clamp(
      x,
      PLAY_AREA.x + this.radius,
      PLAY_AREA.x + PLAY_AREA.width - this.radius,
    );
    this.homeY = Phaser.Math.Clamp(
      y,
      PLAY_AREA.y + this.radius,
      PLAY_AREA.y + PLAY_AREA.height - this.radius,
    );
    this.x = this.homeX;
    this.y = this.homeY;
    this.syncHealthMeterPosition();
  }

  checkBounds() {
    const minX = PLAY_AREA.x + this.radius;
    const maxX = PLAY_AREA.x + PLAY_AREA.width - this.radius;
    const minY = PLAY_AREA.y + this.radius;
    const maxY = PLAY_AREA.y + PLAY_AREA.height - this.radius;
    this.x = Phaser.Math.Clamp(this.x, minX, maxX);
    this.y = Phaser.Math.Clamp(this.y, minY, maxY);
    this.homeX = Phaser.Math.Clamp(this.homeX, minX, maxX);
    this.homeY = Phaser.Math.Clamp(this.homeY, minY, maxY);
  }

  canSplit() {
    return (
      this.isAlive &&
      !this.attachedTo &&
      this.canDivide &&
      this.age - this.lastSplitAt >= this.splitTime
    );
  }

  markSplit() {
    this.lastSplitAt = this.age;
    if (this.splitTimeRange)
      this.splitTime = ConfigManager.randomRange(
        this.splitTimeRange.min,
        this.splitTimeRange.max,
      );
  }

  syncHealthMeterDepth() {
    if (!this.healthBarContainer) return;
    this.healthBarContainer.setDepth(
      this.isDragging ? DEPTHS.DRAGGING_HEALTH_METER : DEPTHS.HEALTH_METER,
    );
  }

  syncHealthMeterPosition() {
    if (!this.healthBarContainer) return;
    this.healthBarContainer.x = this.x;
    this.healthBarContainer.y = this.y - this.radius - 16;
  }

  setDraggingDepth(isDragging) {
    this.setDepth(isDragging ? DEPTHS.DRAGGING_CELL : DEPTHS.NORMAL_CELL);
    this.syncHealthMeterDepth();
  }

  setHealthBarVisible(isVisible) {
    if (!this.healthBarContainer || this.maxHealth <= 0) return;
    this.healthBarContainer.setVisible(!!isVisible);
    this.healthBarBg.setVisible(!!isVisible);
    this.healthBarFill.setVisible(!!isVisible);
  }

  updateHealthBar() {
    if (this.maxHealth <= 0) return;
    const ratio = Phaser.Math.Clamp(this.health / this.maxHealth, 0, 1);
    this.healthBarFill.width = this.radius * 2.2 * ratio;
    if (ratio <= 0.3) this.healthBarFill.setFillStyle(COLORS.danger);
    else if (ratio <= 0.6) this.healthBarFill.setFillStyle(COLORS.yellow);
    else this.healthBarFill.setFillStyle(COLORS.green);
  }

  setCellColor(color) {
    this.currentColor = color;
    this.redrawCellVisual();
  }

  die() {
    if (!this.isAlive) return;
    if (this.attachedTo && this.scene.cellManager)
      this.scene.cellManager.detachHealthyCell(this, false);
    this.isAlive = false;
    if (this.detectionRingTween) this.detectionRingTween.stop();
    if (this.healthBarContainer) this.healthBarContainer.destroy();
    this.destroy();
  }

  getTextureKeyForCurrentState() {
    // Texture keys depend on this level's configured size/color, baked
    // once at GameScene start (see bakeAllCellTextures) and stashed on
    // the scene -- not a fixed global lookup anymore.
    const keys = this.scene && this.scene.cellTextureKeys;
    if (!keys) return null;
    if (this.key === CELL_KEYS.R) return keys.R;
    if (this.key === CELL_KEYS.T) return keys.T;
    if (this.key === CELL_KEYS.K) return keys.K;
    if (this.key === CELL_KEYS.V) return keys.V;
    if (this.key === CELL_KEYS.H) {
      // this.isDetected only exists on CancerCell, but key === H implies
      // this Cell always *is* a CancerCell. Checking the actual flag
      // (rather than comparing currentColor to a fixed default) stays
      // correct even when V's color has been customized away from its
      // default in the Configurator.
      return this.isDetected ? keys.H_DETECTED : keys.H;
    }
    return keys.R;
  }

  // Cells used to redraw their entire body with a Graphics object
  // (~10 draw calls) every time their color/state changed. Now every
  // possible look is a pre-baked texture (see bakeAllCellTextures), so
  // "redrawing" is just pointing the sprite at a different texture --
  // no geometry is recomputed and WebGL can batch same-texture cells
  // into a single draw call.
  redrawCellVisual() {
    this.cellGraphics.setTexture(this.getTextureKeyForCurrentState());
  }
}

class HealthyCell extends Cell {}

class CancerCell extends Cell {
  constructor(scene, x, y, def, config) {
    super(scene, x, y, def, config);
    this.isDetected = def.key === CELL_KEYS.V;
    this.detectedColor = def.detectedColor || COLORS.v;
    this.impactOnPlayerHealth = def.impactOnPlayerHealth;
    this.attachedCells = new Set();
    this.lastDamageFeedbackAt = 0;
    this.lastManualClickAttackAt = 0;
    // Ambient "bad protein" dust emission -- a passive tell that this
    // cell is actively harmful. Staggered start + randomized interval so
    // cancer cells don't all puff in lockstep.
    this.dustTimer = Phaser.Math.FloatBetween(0, 1);
    this.dustInterval = Phaser.Math.FloatBetween(0.6, 1.2);
    this.bodyCircle.on('pointerup', (p) => {
      if (!this.isAlive || this.scene.isFinished) return;
      if (this.scene.time.now < this.suppressClickUntil) return;
      p.event.stopPropagation();
      this.scene.cellManager.handleCancerCellClick(this);
    });
  }

  updateCell(dt) {
    super.updateCell(dt);
    this.updateDustEmission(dt);
  }

  // Only cells the player can currently *see* as cancerous emit dust:
  // an always-visible V-cell, or an H-cell only after it's been
  // detected. An undetected H-cell must stay indistinguishable from a
  // normal R-cell, so it emits nothing until revealed. The two also use
  // different dust colors so a freshly-revealed H-cell still reads as
  // "the one that was hiding" rather than looking identical to a V-cell.
  updateDustEmission(dt) {
    if (!this.isAlive) return;
    const emitsDust =
      this.key === CELL_KEYS.V || (this.key === CELL_KEYS.H && this.isDetected);
    if (!emitsDust) return;
    this.dustTimer += dt;
    if (this.dustTimer < this.dustInterval) return;
    this.dustTimer = 0;
    this.dustInterval = Phaser.Math.FloatBetween(0.6, 1.2);
    this.spawnDustParticle();
  }

  spawnDustParticle() {
    if (!this.scene || !this.isAlive) return;
    // V-cells leak a toxic teal clump. A detected H-cell keeps leaking
    // its original hidden-red color, marking it as "the one that was
    // disguised" even though it now looks the same as a V-cell.
    const dustColor = this.key === CELL_KEYS.H ? 0x8b0000 : 0x0891b2;
    const angle = Phaser.Math.FloatBetween(0, Math.PI * 2);
    const startDistance = this.radius * Phaser.Math.FloatBetween(0.3, 0.7);
    const particle = this.scene.add.image(
      this.x + Math.cos(angle) * startDistance,
      this.y + Math.sin(angle) * startDistance,
      DUST_PROTEIN_TEXTURE_KEY,
    );
    particle.setTint(dustColor);
    particle.setAlpha(0.8);
    particle.setRotation(Phaser.Math.FloatBetween(0, Math.PI * 2));
    particle.setScale(Phaser.Math.FloatBetween(0.7, 1.3));
    particle.setDepth(this.depth + 5);
    const driftAngle = angle + Phaser.Math.FloatBetween(-0.4, 0.4);
    const driftDistance = this.radius * Phaser.Math.FloatBetween(1.4, 2.2);
    // A lazy tumble as it drifts, unlike the attack sparks which never
    // rotate -- reinforces that this is a different kind of particle.
    const spin = Phaser.Math.FloatBetween(-2.4, 2.4);
    this.scene.tweens.add({
      targets: particle,
      x: particle.x + Math.cos(driftAngle) * driftDistance,
      y: particle.y + Math.sin(driftAngle) * driftDistance - 16,
      rotation: particle.rotation + spin,
      alpha: 0,
      scale: 0.35,
      duration: Phaser.Math.Between(900, 1400),
      ease: 'Sine.easeOut',
      onComplete: () => particle.destroy(),
    });
  }

  detect() {
    if (this.key !== CELL_KEYS.H || this.isDetected) return;
    this.isDetected = true;
    this.setCellColor(this.detectedColor);
    this.scene.tweens.add({
      targets: this,
      scaleX: 1.12,
      scaleY: 1.12,
      duration: 180,
      ease: 'Back.Out',
    });
  }

  takeDamage(amount, details, options = {}) {
    if (!this.isAlive || amount <= 0) return;
    this.health -= amount;
    this.updateHealthBar();
    const now = this.scene.time.now;
    const shouldShowFeedback =
      options.forceFeedback ||
      now - this.lastDamageFeedbackAt >= 240 ||
      this.health <= 0;
    if (shouldShowFeedback) {
      this.lastDamageFeedbackAt = now;
      this.showDamageReaction(options);
    }
    if (this.health <= 0) {
      this.scene.showFloatingText(this.x, this.y, 'Destroyed', '#bbf7d0');
      this.die();
    }
  }

  showDamageReaction(options = {}) {
    if (!this.isAlive || !this.scene) return;
    const isManual = !!options.manual;
    const ringColor = isManual ? 0xfde047 : 0xff4d6d;
    const particleColor = isManual ? 0xfff7ad : 0xff8fa3;

    const ring = this.scene.add.circle(
      this.x,
      this.y,
      this.radius * 0.85,
      ringColor,
      0,
    );
    ring.setStrokeStyle(isManual ? 6 : 4, ringColor, isManual ? 0.9 : 0.7);
    ring.setDepth(this.depth + 8);
    this.scene.tweens.add({
      targets: ring,
      scale: isManual ? 2.25 : 1.85,
      alpha: 0,
      duration: isManual ? 360 : 280,
      ease: 'Sine.easeOut',
      onComplete: () => ring.destroy(),
    });

    const flash = this.scene.add.circle(
      this.x,
      this.y,
      this.radius * 0.95,
      isManual ? 0xfff3a3 : 0xff3355,
      isManual ? 0.32 : 0.24,
    );
    flash.setDepth(this.depth + 7);
    this.scene.tweens.add({
      targets: flash,
      scaleX: 1.12,
      scaleY: 1.12,
      alpha: 0,
      duration: 160,
      ease: 'Quad.easeOut',
      onComplete: () => flash.destroy(),
    });

    for (let i = 0; i < 8; i++) {
      const angle = Phaser.Math.FloatBetween(0, Math.PI * 2);
      const startDistance = this.radius * Phaser.Math.FloatBetween(0.45, 0.9);
      const endDistance = this.radius * Phaser.Math.FloatBetween(1.35, 1.95);
      const dot = this.scene.add.circle(
        this.x + Math.cos(angle) * startDistance,
        this.y + Math.sin(angle) * startDistance,
        Phaser.Math.FloatBetween(2.4, 4.8),
        particleColor,
        0.9,
      );
      dot.setDepth(this.depth + 9);
      this.scene.tweens.add({
        targets: dot,
        x: this.x + Math.cos(angle) * endDistance,
        y: this.y + Math.sin(angle) * endDistance,
        alpha: 0,
        scale: 0.35,
        duration: Phaser.Math.Between(220, 380),
        ease: 'Sine.easeOut',
        onComplete: () => dot.destroy(),
      });
    }

    this.scene.tweens.add({
      targets: this,
      scaleX: isManual ? 1.14 : 1.08,
      scaleY: isManual ? 0.82 : 0.88,
      yoyo: true,
      duration: isManual ? 95 : 80,
      ease: 'Sine.easeInOut',
    });
  }

  die() {
    if (this.attachedCells) {
      Array.from(this.attachedCells).forEach((c) =>
        this.scene.cellManager.detachHealthyCell(c, true),
      );
      this.attachedCells.clear();
    }
    super.die();
  }
}

class CellManager {
  constructor(scene, config) {
    this.scene = scene;
    this.config = config;
    this.cells = [];
    this.manualClickCooldownMs = 220;
  }

  createInitialCells() {
    if (this.config.id === 'tutorial') {
      this.createTutorialCells();
      return;
    }
    const counts = ConfigManager.distributionToCounts(this.config);
    Object.entries(counts).forEach(([key, count]) => {
      for (let i = 0; i < count; i++) this.createCell(key);
    });
  }

  createTutorialCells() {
    this.createCell(CELL_KEYS.V, PLAY_AREA.x + 1080, PLAY_AREA.y + 310);
    this.createCell(CELL_KEYS.H, PLAY_AREA.x + 1260, PLAY_AREA.y + 560);
    this.createCell(CELL_KEYS.T, PLAY_AREA.x + 520, PLAY_AREA.y + 310);
    this.createCell(CELL_KEYS.K, PLAY_AREA.x + 520, PLAY_AREA.y + 560);
    this.createCell(CELL_KEYS.R, PLAY_AREA.x + 350, PLAY_AREA.y + 430);
    this.createCell(CELL_KEYS.R, PLAY_AREA.x + 690, PLAY_AREA.y + 430);
  }

  createCell(key, x, y, currentAliveCount) {
    const aliveCount =
      currentAliveCount === undefined
        ? this.getAliveCells().length
        : currentAliveCount;
    if (aliveCount >= Number(this.config.maxCells)) return null;
    const def = ConfigManager.getCellDef(key, this.config);
    const pos = this.getSpawnPosition(x, y, def.radius);
    const Cls = def.category === 'cancer' ? CancerCell : HealthyCell;
    const cell = new Cls(this.scene, pos.x, pos.y, def, this.config);
    cell.setHomePosition(pos.x, pos.y);
    cell.setDepth(DEPTHS.NORMAL_CELL);
    this.cells.push(cell);
    return cell;
  }

  getSpawnPosition(x, y, radius) {
    if (typeof x === 'number' && typeof y === 'number') {
      const angle = Phaser.Math.FloatBetween(0, Math.PI * 2);
      const distance = radius * 2.7;
      return {
        x: Phaser.Math.Clamp(
          x + Math.cos(angle) * distance,
          PLAY_AREA.x + radius,
          PLAY_AREA.x + PLAY_AREA.width - radius,
        ),
        y: Phaser.Math.Clamp(
          y + Math.sin(angle) * distance,
          PLAY_AREA.y + radius,
          PLAY_AREA.y + PLAY_AREA.height - radius,
        ),
      };
    }
    return {
      x: Phaser.Math.Between(
        PLAY_AREA.x + radius,
        PLAY_AREA.x + PLAY_AREA.width - radius,
      ),
      y: Phaser.Math.Between(
        PLAY_AREA.y + radius,
        PLAY_AREA.y + PLAY_AREA.height - radius,
      ),
    };
  }

  update(dt) {
    // Update every cell once, then take a single snapshot of the alive
    // cells for this frame. All sub-systems below reuse that snapshot
    // instead of each re-filtering the full cell list (which used to
    // happen 8-10+ times per frame).
    for (let i = 0; i < this.cells.length; i++) this.cells[i].updateCell(dt);
    const alive = this.getAliveCells();
    this.updateHiddenCancerDetection(alive);
    this.handleAutoAttachment(alive);
    this.handleAutoAttacks(dt, alive);
    this.handleSplits(alive);
    this.resolveSoftOverlaps(alive);
    this.removeDeadCells();
  }

  // Attachment used to require dragging a healthy cell onto a cancer
  // cell and releasing it. Now simple physical contact is enough: any
  // free-floating (not already attached, not being dragged) T- or
  // K-cell that touches a cancer cell auto-attaches, same as a manual
  // drag-and-drop would. Actual damage still only starts once attached
  // (see handleAutoAttacks / getCorrectAttackers) -- this method only
  // creates the attachment, it never deals damage itself.
  //
  // R-cells are deliberately excluded: they're passive (no attack), so
  // they shouldn't auto-latch onto a cancer cell just from incidental
  // contact -- including when a cancer cell is dragged into a resting
  // R-cell. (Manually dragging an R-cell onto a cancer cell and
  // releasing it is unrelated to this method and still works as before.)
  handleAutoAttachment(aliveCells) {
    const cancerCells = aliveCells.filter(
      (c) => c.category === 'cancer' && c.isAlive,
    );
    if (!cancerCells.length) return;
    for (const h of aliveCells) {
      if (
        (h.key !== CELL_KEYS.T && h.key !== CELL_KEYS.K) ||
        !h.isAlive ||
        h.attachedTo ||
        h.isDragging
      )
        continue;
      const touching = cancerCells.some((cancer) => {
        const dist = Phaser.Math.Distance.Between(h.x, h.y, cancer.x, cancer.y);
        // Actual physical contact (small buffer), not the more generous
        // "close enough" range used when releasing a manual drag.
        return dist <= h.radius + cancer.radius + 4;
      });
      if (touching) this.attachHealthyCellToNearestCancer(h);
    }
  }

  handleSplits(aliveCells) {
    if (this.config.id === 'tutorial') return;
    const maxCells = Number(this.config.maxCells);
    // Track the alive count locally instead of re-filtering the whole
    // array on every loop iteration (that was an accidental O(n^2)).
    let currentCount = aliveCells.length;
    for (const cell of aliveCells) {
      if (currentCount >= maxCells) break;
      if (!cell.canSplit()) continue;
      cell.markSplit();
      this.scene.tweens.add({
        targets: cell,
        scaleX: 1.25,
        scaleY: 0.8,
        duration: 180,
        yoyo: true,
      });
      const child = this.createCell(cell.key, cell.x, cell.y, currentCount);
      if (!child) continue;
      currentCount++;
      child.age = 0;
      child.setHomePosition(child.x, child.y);
      child.setScale(0.15);
      this.scene.tweens.add({
        targets: child,
        scaleX: 1,
        scaleY: 1,
        duration: 350,
        ease: 'Back.Out',
      });
      const burst = this.scene.add
        .circle(cell.x, cell.y, 10, 0xffffff, 0.4)
        .setDepth(DEPTHS.NORMAL_CELL - 1);
      this.scene.tweens.add({
        targets: burst,
        scale: 5,
        alpha: 0,
        duration: 300,
        onComplete: () => burst.destroy(),
      });
      this.scene.showFloatingText(
        child.x,
        child.y - child.radius - 18,
        'Split',
        '#93c5fd',
      );
    }
  }

  // Overlap resolution used to be an O(n^2) brute-force pass over every
  // alive cell against every other alive cell. With ~150-165 cells alive
  // (Level 3's maxCells) that is 12,000+ pair checks, every single frame.
  // Cells only ever need to resolve overlaps with *nearby* cells, so we
  // bucket them into a uniform grid keyed by position and only compare
  // cells that share or neighbor a bucket. This turns the check into
  // roughly O(n) in practice while producing the same result.
  resolveSoftOverlaps(aliveCells) {
    const cellSize = 140; // > max possible "desired" separation (~104px)
    const grid = new Map();
    for (const c of aliveCells) {
      const gx = Math.floor(c.x / cellSize);
      const gy = Math.floor(c.y / cellSize);
      const key = gx + ',' + gy;
      let bucket = grid.get(key);
      if (!bucket) {
        bucket = [];
        grid.set(key, bucket);
      }
      bucket.push(c);
    }

    // These 5 offsets (including self) cover the full 3x3 neighborhood
    // exactly once per pair when iterated over every occupied bucket,
    // so no pair is checked twice and none is missed.
    const neighborOffsets = [
      [0, 0],
      [1, 0],
      [0, 1],
      [1, 1],
      [-1, 1],
    ];

    for (const [key, bucket] of grid) {
      const parts = key.split(',');
      const gx = Number(parts[0]);
      const gy = Number(parts[1]);
      for (const [ox, oy] of neighborOffsets) {
        const otherBucket = grid.get(gx + ox + ',' + (gy + oy));
        if (!otherBucket) continue;
        const sameBucket = ox === 0 && oy === 0;
        for (let i = 0; i < bucket.length; i++) {
          const a = bucket[i];
          if (!a.isAlive) continue;
          const startJ = sameBucket ? i + 1 : 0;
          for (let j = startJ; j < otherBucket.length; j++) {
            const b = otherBucket[j];
            if (!b.isAlive) continue;
            const ownerA = a.attachedTo || a;
            const ownerB = b.attachedTo || b;
            if (ownerA === ownerB) continue;
            const desired = a.radius + b.radius + 4;
            const dx = b.x - a.x;
            const dy = b.y - a.y;
            const distance = Math.sqrt(dx * dx + dy * dy) || 0.001;
            if (distance >= desired) continue;
            const overlap = desired - distance;
            const nx = dx / distance;
            const ny = dy / distance;
            a.applyCollisionSqueeze(nx, ny, overlap);
            b.applyCollisionSqueeze(-nx, -ny, overlap);
            const push = overlap * 0.08;
            if (!ownerA.isDragging)
              this.moveCollisionOwner(ownerA, -nx * push, -ny * push);
            if (!ownerB.isDragging)
              this.moveCollisionOwner(ownerB, nx * push, ny * push);
          }
        }
      }
    }
  }

  moveCollisionOwner(cell, dx, dy) {
    if (!cell || !cell.isAlive || cell.isDragging) return;
    const minX = PLAY_AREA.x + cell.radius;
    const maxX = PLAY_AREA.x + PLAY_AREA.width - cell.radius;
    const minY = PLAY_AREA.y + cell.radius;
    const maxY = PLAY_AREA.y + PLAY_AREA.height - cell.radius;
    cell.homeX = Phaser.Math.Clamp(cell.homeX + dx, minX, maxX);
    cell.homeY = Phaser.Math.Clamp(cell.homeY + dy, minY, maxY);
    cell.x = Phaser.Math.Clamp(cell.x + dx, minX, maxX);
    cell.y = Phaser.Math.Clamp(cell.y + dy, minY, maxY);
    cell.syncHealthMeterPosition();
    if (
      cell.category === 'cancer' &&
      cell.attachedCells &&
      cell.attachedCells.size > 0
    )
      this.rebuildCancerAttachments(cell);
  }

  attachHealthyCellToNearestCancer(healthyCell) {
    if (
      !healthyCell ||
      healthyCell.category !== 'healthy' ||
      !healthyCell.isAlive
    )
      return false;
    const cancerCells = this.getAliveCells().filter(
      (c) => c.category === 'cancer',
    );
    let best = null;
    let bestDistance = Infinity;
    cancerCells.forEach((cancer) => {
      const distance = Phaser.Math.Distance.Between(
        healthyCell.x,
        healthyCell.y,
        cancer.x,
        cancer.y,
      );
      const attachDistance = cancer.radius + healthyCell.radius + 52;
      if (distance <= attachDistance && distance < bestDistance) {
        best = cancer;
        bestDistance = distance;
      }
    });
    if (!best) return false;
    this.detachHealthyCell(healthyCell, false);
    healthyCell.attachedTo = best;
    best.attachedCells.add(healthyCell);
    this.rebuildCancerAttachments(best);
    if (this.isCorrectAttacker(healthyCell, best))
      best.setHealthBarVisible(true);
    if (best.key === CELL_KEYS.H && healthyCell.key === CELL_KEYS.K) {
      best.detect();
      this.scene.showFloatingText(
        best.x,
        best.y - best.radius - 34,
        'Detected by K-cell',
        '#67e8f9',
      );
    }
    this.scene.showFloatingText(
      best.x,
      best.y + best.radius + 30,
      this.getAttachmentRuleText(healthyCell, best),
      '#bbf7d0',
    );
    return true;
  }

  detachHealthyCell(healthyCell, restoreHome) {
    if (!healthyCell || !healthyCell.attachedTo) return;
    const target = healthyCell.attachedTo;
    if (target.attachedCells) target.attachedCells.delete(healthyCell);
    healthyCell.attachedTo = null;
    healthyCell.attachedOffset = { x: 0, y: 0 };
    if (restoreHome) healthyCell.setHomePosition(healthyCell.x, healthyCell.y);
    if (target && target.isAlive) {
      this.rebuildCancerAttachments(target);
      this.updateCancerHealthVisibility(target);
    }
  }

  rebuildCancerAttachments(cancerCell) {
    if (!cancerCell || !cancerCell.attachedCells) return;
    const attached = Array.from(cancerCell.attachedCells).filter(
      (c) => c && c.isAlive,
    );
    cancerCell.attachedCells = new Set(attached);
    const total = Math.max(attached.length, 1);
    attached.forEach((cell, index) => {
      const angle = -Math.PI / 2 + (index * Math.PI * 2) / total;
      const ringRadius = cancerCell.radius + cell.radius + 10;
      cell.attachedOffset = {
        x: Math.cos(angle) * ringRadius,
        y: Math.sin(angle) * ringRadius,
      };
      cell.x = cancerCell.x + cell.attachedOffset.x;
      cell.y = cancerCell.y + cell.attachedOffset.y;
      cell.homeX = cell.x;
      cell.homeY = cell.y;
      cell.syncHealthMeterPosition();
      cell.syncHealthMeterDepth();
    });
  }

  getAttachmentRuleText(h, c) {
    if (h.key === CELL_KEYS.T && c.key === CELL_KEYS.V)
      return 'T-cell attached: auto attack enabled';
    if (h.key === CELL_KEYS.K && c.key === CELL_KEYS.H)
      return 'K-cell attached: auto attack enabled';
    if (h.key === CELL_KEYS.R) return 'R-cell attached: no attack damage';
    return 'Attached, but not the correct attacker';
  }

  updateHiddenCancerDetection(aliveCells) {
    const undetectedHidden = aliveCells.filter(
      (c) => c.key === CELL_KEYS.H && !c.isDetected,
    );
    if (!undetectedHidden.length) return;
    const kCells = aliveCells.filter((c) => c.key === CELL_KEYS.K && c.isAlive);
    if (!kCells.length) return;
    const buffer = K_CELL_DETECTION_BUFFER;
    undetectedHidden.forEach((h) => {
      const isNearK = kCells.some((k) => {
        const range = h.radius + k.radius + buffer;
        return Phaser.Math.Distance.Between(h.x, h.y, k.x, k.y) <= range;
      });
      if (isNearK) {
        h.detect();
        this.scene.showFloatingText(
          h.x,
          h.y - h.radius - 30,
          'Detected',
          '#67e8f9',
        );
      }
    });
  }

  isCorrectAttacker(healthyCell, cancerCell) {
    if (!healthyCell || !cancerCell) return false;
    return (
      (healthyCell.key === CELL_KEYS.T && cancerCell.key === CELL_KEYS.V) ||
      (healthyCell.key === CELL_KEYS.K && cancerCell.key === CELL_KEYS.H)
    );
  }

  getCorrectAttackers(cancerCell) {
    const attached = cancerCell.attachedCells
      ? Array.from(cancerCell.attachedCells).filter((c) => c && c.isAlive)
      : [];
    if (cancerCell.key === CELL_KEYS.V)
      return attached.filter((c) => c.key === CELL_KEYS.T);
    if (cancerCell.key === CELL_KEYS.H && cancerCell.isDetected)
      return attached.filter((c) => c.key === CELL_KEYS.K);
    return [];
  }

  updateCancerHealthVisibility(cancerCell) {
    if (!cancerCell || !cancerCell.isAlive || cancerCell.category !== 'cancer')
      return;
    cancerCell.setHealthBarVisible(
      this.getCorrectAttackers(cancerCell).length > 0,
    );
  }

  handleAutoAttacks(dt, aliveCells) {
    if (this.scene.isFinished) return;
    aliveCells
      .filter((cell) => cell.category === 'cancer')
      .forEach((cancerCell) => {
        const attackers = this.getCorrectAttackers(cancerCell);
        this.updateCancerHealthVisibility(cancerCell);
        if (!attackers.length) return;
        const dpsConfig =
          this.config.damagePerSecond || this.config.cellDamage || {};
        const totalDps = attackers.reduce(
          (sum, attacker) =>
            sum + Number(dpsConfig[attacker.key] || attacker.hitsPerClick || 0),
          0,
        );
        const damage = totalDps * dt;
        if (damage <= 0) return;
        cancerCell.takeDamage(damage, '', {
          forceFeedback: false,
          manual: false,
        });
      });
  }

  getManualClickDamage(attackers) {
    const clickDamageConfig = this.config.cellDamage || {};
    return attackers.reduce(
      (sum, attacker) =>
        sum +
        Number(clickDamageConfig[attacker.key] || attacker.hitsPerClick || 0),
      0,
    );
  }

  handleCancerCellClick(cancerCell) {
    if (!cancerCell || !cancerCell.isAlive || this.scene.isFinished) return;
    const attackers = this.getCorrectAttackers(cancerCell);
    if (attackers.length > 0) {
      const now = this.scene.time.now;
      if (now - cancerCell.lastManualClickAttackAt < this.manualClickCooldownMs)
        return;
      cancerCell.lastManualClickAttackAt = now;
      const damage = this.getManualClickDamage(attackers);
      if (damage <= 0) return;
      cancerCell.takeDamage(damage, '', { forceFeedback: true, manual: true });
      return;
    }
    this.scene.showFloatingText(
      cancerCell.x,
      cancerCell.y - cancerCell.radius - 35,
      cancerCell.key === CELL_KEYS.V
        ? 'Attach T-cell to this V-cell'
        : 'Attach K-cell to this H-cell',
      '#fecaca',
    );
  }

  getAliveCells() {
    return this.cells.filter((c) => c && c.isAlive && c.active);
  }
  getCountByKey(key) {
    return this.getAliveCells().filter((c) => c.key === key).length;
  }
  getCancerCounts() {
    return {
      visible: this.getCountByKey(CELL_KEYS.V),
      hidden: this.getCountByKey(CELL_KEYS.H),
    };
  }
  removeDeadCells() {
    this.cells = this.cells.filter((c) => c && c.isAlive && c.active);
  }
  destroy() {
    this.cells.forEach((c) => {
      if (c && c.active) c.destroy();
      if (c && c.healthBarContainer) c.healthBarContainer.destroy();
    });
    this.cells = [];
  }
}

class HealthManager {
  constructor(scene, config) {
    this.scene = scene;
    this.config = config;
    this.maxHealth = Number(config.playerHealth);
    this.playerHealth = Number(config.playerHealth);
    this.dangerThreshold =
      (this.maxHealth * Number(config.playerHealthDangerThresholdPercent)) /
      100;
    this.accumulator = 0;
  }

  update(dt) {
    if (this.scene.isFinished || this.config.id === 'tutorial') return;
    this.accumulator += dt;
    if (this.accumulator >= Number(this.config.cancerDamageInterval)) {
      this.accumulator -= Number(this.config.cancerDamageInterval);
      this.applyCancerDamage();
    }
  }

  applyCancerDamage() {
    const counts = this.scene.cellManager.getCancerCounts();
    const damage =
      counts.visible * Number(this.config.impacts.VISIBLE_CANCER_CELL) +
      counts.hidden * Number(this.config.impacts.HIDDEN_CANCER_CELL);
    if (damage <= 0) return;
    this.playerHealth = Phaser.Math.Clamp(
      this.playerHealth - damage,
      0,
      this.maxHealth,
    );
    if (this.scene.hud) this.scene.hud.showDamageEffect(damage);
    if (this.playerHealth <= this.dangerThreshold)
      this.scene.finishGame(
        false,
        'Player health reached the danger threshold.',
      );
  }

  ratio() {
    return Phaser.Math.Clamp(this.playerHealth / this.maxHealth, 0, 1);
  }
}

class HtmlHUD {
  static ensureDamageStyles() {
    if (document.getElementById('cell-defense-damage-styles')) return;
    const style = document.createElement('style');
    style.id = 'cell-defense-damage-styles';
    style.textContent = `
      .game-hud { overflow: visible !important; align-items: flex-start !important; }
      .hud-right { overflow: visible !important; min-width: 360px !important; display: flex !important; flex-direction: row !important; align-items: stretch !important; gap: 8px !important; }
      .hud-center { overflow: visible !important; }
      .health-bar { position: relative; overflow: hidden; }
      .health-damage-flash { position: absolute; inset: 0; border-radius: inherit; opacity: 0; pointer-events: none; background: linear-gradient(90deg, rgba(239,68,68,0.82), rgba(248,113,113,0.24)); box-shadow: 0 0 24px rgba(239,68,68,0.9), inset 0 0 16px rgba(255,255,255,0.45); z-index: 3; }
      .health-damage-flash.hit { animation: cd-health-hit 420ms ease-out; }
      @keyframes cd-health-hit { 0% { opacity: 0; transform: translateX(-100%) scaleX(0.45); } 24% { opacity: 1; transform: translateX(0) scaleX(1); } 100% { opacity: 0; transform: translateX(0) scaleX(1.08); } }
      .heart-monitor { width: 320px; min-height: 74px; display: block; flex: 0 0 auto; box-sizing: border-box; margin-top: 0; border-radius: 16px; padding: 8px 12px 7px; border: 1px solid rgba(255,255,255,0.42); box-shadow: 0 10px 22px rgba(15,23,42,0.18), inset 0 0 18px rgba(255,255,255,0.28); transition: background 260ms ease, box-shadow 260ms ease, border-color 260ms ease; position: relative; z-index: 4; }
      .heart-monitor .heart-header { display: flex; justify-content: space-between; align-items: center; font-family: Arial, sans-serif; font-size: 12px; font-weight: 800; letter-spacing: 0.07em; margin-bottom: 3px; }
      .heart-monitor svg { display: block; width: 100%; height: 42px; overflow: visible; }
      .heart-wave { fill: none; stroke-width: 4; stroke-linecap: round; stroke-linejoin: round; stroke-dasharray: 255; animation: cd-heart-wave 1.1s linear infinite; filter: drop-shadow(0 0 5px currentColor); }
      .heart-monitor.relaxed { color: #10b981; background: linear-gradient(135deg, rgba(209,250,229,0.94), rgba(224,242,254,0.9)); border-color: rgba(16,185,129,0.5); box-shadow: 0 0 18px rgba(16,185,129,0.24), inset 0 0 20px rgba(255,255,255,0.5); }
      .heart-monitor.watch { color: #f59e0b; background: linear-gradient(135deg, rgba(254,243,199,0.96), rgba(255,251,235,0.88)); border-color: rgba(245,158,11,0.6); box-shadow: 0 0 20px rgba(245,158,11,0.34), inset 0 0 16px rgba(255,255,255,0.42); }
      .heart-monitor.danger { color: #ef4444; background: linear-gradient(135deg, rgba(254,226,226,0.96), rgba(255,237,213,0.9)); border-color: rgba(239,68,68,0.75); box-shadow: 0 0 24px rgba(239,68,68,0.44), inset 0 0 18px rgba(255,255,255,0.34); animation: cd-monitor-warning 720ms ease-in-out infinite alternate; }
      @keyframes cd-heart-wave { from { stroke-dashoffset: 255; } to { stroke-dashoffset: 0; } }
      @keyframes cd-monitor-warning { from { transform: scale(1); } to { transform: scale(1.025); } }
    `;
    document.head.appendChild(style);
  }

  constructor(scene, config) {
    this.scene = scene;
    this.config = config;
    HtmlHUD.ensureDamageStyles();
    this.dom = scene.add.dom(GAME_WIDTH / 2, 78).createFromHTML(this.getHTML());
    this.dom.setDepth(DEPTHS.HUD);
    this.levelName = this.dom.node.querySelector('#hudLevelName');
    this.subtitle = this.dom.node.querySelector('#hudSubtitle');
    this.healthFill = this.dom.node.querySelector('#hudHealthFill');
    this.healthDamageFlash = this.dom.node.querySelector(
      '#hudHealthDamageFlash',
    );
    this.healthText = this.dom.node.querySelector('#hudHealthText');
    this.timer = this.dom.node.querySelector('#hudTimer');
    this.stats = this.dom.node.querySelector('#hudStats');
    this.counters = this.dom.node.querySelector('#hudCounters');
    this.heartMonitor = this.dom.node.querySelector('#heartMonitor');
    this.heartStatus = this.dom.node.querySelector('#heartStatus');
    this.heartBpm = this.dom.node.querySelector('#heartBpm');
    this.heartWave = this.dom.node.querySelector('#heartWave');
    this.levelName.textContent = config.name;
    this.subtitle.textContent =
      'Drag cells. Attach T to V and K to H. Correct attachments auto-attack.';
    this.stats.innerHTML = this.getStatsHTML();
  }

  getHTML() {
    return `<div class="game-hud"><div class="hud-left"><div id="hudLevelName" class="hud-level"></div><div class="health-row"><div class="health-bar"><div id="hudHealthDamageFlash" class="health-damage-flash"></div><div id="hudHealthFill" class="health-fill"></div></div><div id="hudHealthText" class="health-text"></div></div><div id="hudSubtitle" class="hud-subtitle"></div></div><div class="hud-center"><div id="hudTimer" class="hud-timer">0s</div><div class="hud-timer-label">Play Time Left</div></div><div class="hud-right"><div id="heartMonitor" class="heart-monitor relaxed"><div class="heart-header"><span id="heartStatus">RELAXED</span><span id="heartBpm">72 BPM</span></div><svg viewBox="0 0 220 48" aria-hidden="true"><polyline id="heartWave" class="heart-wave" points="0,30 22,30 31,18 43,39 57,11 72,30 94,30 104,24 115,34 126,30 220,30"></polyline></svg></div><div id="hudStats" class="hud-stats"></div><div id="hudCounters" class="hud-counters"></div></div></div>`;
  }

  getStatsHTML() {
    const dps = this.config.damagePerSecond || this.config.cellDamage;
    return `<div class="hud-kpi"><span>T DPS</span><strong>${dps.T_CELL}</strong></div><div class="hud-kpi"><span>K DPS</span><strong>${dps.K_CELL}</strong></div><div class="hud-kpi"><span>V HP</span><strong>${this.config.cancerHealth.VISIBLE_CANCER_CELL}</strong></div><div class="hud-kpi"><span>H HP</span><strong>${this.config.cancerHealth.HIDDEN_CANCER_CELL}</strong></div>`;
  }

  updateHeartMonitor(ratio) {
    if (!this.heartMonitor || !this.heartStatus || !this.heartBpm) return;
    let mode = 'relaxed';
    let label = 'RELAXED';
    if (ratio <= 0.35) {
      mode = 'danger';
      label = 'CAUTION';
    } else if (ratio <= 0.6) {
      mode = 'watch';
      label = 'WATCH';
    }
    const bpm = Math.round(62 + (1 - ratio) * 72);
    this.heartMonitor.className = 'heart-monitor ' + mode;
    this.heartStatus.textContent = label;
    this.heartBpm.textContent = bpm + ' BPM';
    if (this.heartWave) {
      const speed = Phaser.Math.Clamp(60 / bpm, 0.42, 1.18);
      this.heartWave.style.animationDuration = speed + 's';
      this.heartWave.style.stroke =
        mode === 'danger'
          ? '#ef4444'
          : mode === 'watch'
            ? '#f59e0b'
            : '#10b981';
    }
  }

  update() {
    const h = this.scene.healthManager;
    const ratio = h.ratio();
    const percent = Math.round(ratio * 100);

    // Dirty-check every DOM write below: this update() runs 60x/sec, and
    // writing style/textContent even to an unchanged value still costs a
    // style recalculation. Skipping unchanged writes is free correctness
    // (nothing visually changes) and cuts most of the per-frame DOM cost.
    if (percent !== this._lastPercent) {
      this._lastPercent = percent;
      this.healthFill.style.width = percent + '%';
      let mode = 'healthy';
      if (ratio <= 0.35) mode = 'danger';
      else if (ratio <= 0.6) mode = 'watch';
      if (mode !== this._lastHealthMode) {
        this._lastHealthMode = mode;
        if (mode === 'danger') {
          this.healthFill.style.background =
            'linear-gradient(90deg,#ef4444,#dc2626)';
          this.healthFill.style.boxShadow = '0 0 18px rgba(239,68,68,.8)';
        } else if (mode === 'watch') {
          this.healthFill.style.background =
            'linear-gradient(90deg,#f59e0b,#fbbf24)';
          this.healthFill.style.boxShadow = '0 0 14px rgba(245,158,11,.6)';
        } else {
          this.healthFill.style.background =
            'linear-gradient(90deg,#10b981,#22c55e)';
          this.healthFill.style.boxShadow = '0 0 14px rgba(16,185,129,.5)';
        }
      }
      this.healthText.textContent =
        'Health ' + Math.ceil(h.playerHealth) + ' / ' + h.maxHealth;
      this.updateHeartMonitor(ratio);
    }

    const remaining = Math.max(0, Math.ceil(this.scene.remainingTime));
    if (remaining !== this._lastRemaining) {
      this._lastRemaining = remaining;
      this.timer.textContent = remaining + 's';
      this.timer.style.color = remaining <= 15 ? '#dc2626' : '#0f172a';
    }

    // hud-stats / hud-counters are permanently `display:none` in CSS and
    // nothing in the game ever toggles that, so they're never visible.
    // Recomputing hudCounters every frame used to cost 6 full passes over
    // the cell list (getCountByKey x5 + getAliveCells) for a DOM write
    // nobody can see. Only do that work if the panel is actually enabled.
    if (this.countersVisible) {
      const m = this.scene.cellManager;
      const alive = m.getAliveCells();
      const countBy = (key) =>
        alive.reduce((n, c) => n + (c.key === key ? 1 : 0), 0);
      this.counters.innerHTML = [
        'R: ' + countBy(CELL_KEYS.R),
        'T: ' + countBy(CELL_KEYS.T),
        'K: ' + countBy(CELL_KEYS.K),
        'V: ' + countBy(CELL_KEYS.V),
        'H: ' + countBy(CELL_KEYS.H),
        'Total: ' + alive.length + '/' + this.config.maxCells,
      ].join('<br>');
    }
  }

  showDamageEffect() {
    if (!this.dom || !this.healthDamageFlash) return;
    this.healthDamageFlash.classList.remove('hit');
    void this.healthDamageFlash.offsetWidth;
    this.healthDamageFlash.classList.add('hit');
    const pulse = this.scene.add.rectangle(
      GAME_WIDTH / 2 - 395,
      92,
      290,
      24,
      0xef4444,
      0.28,
    );
    pulse.setDepth(DEPTHS.HUD + 2);
    this.scene.tweens.add({
      targets: pulse,
      scaleX: 1.18,
      scaleY: 1.7,
      alpha: 0,
      duration: 420,
      ease: 'Quad.easeOut',
      onComplete: () => pulse.destroy(),
    });
  }

  destroy() {
    if (this.dom) this.dom.destroy();
  }
}

// Ambient animated backdrop (gradient wash, drifting tissue blobs with
// organelles/nucleus, fluid particles, ECM matrix lines) run as its own
// parallel Scene rather than objects inside GameScene. GameScene
// launches it and immediately sends it to the back of the render order
// (see GameScene.create/cleanUp below), so it renders full-canvas behind
// the play-area dish and HUD, and shuts down cleanly when leaving the
// level -- it never runs during Config/LevelSelect/Result screens.
class TissueScene extends Phaser.Scene {
  constructor() {
    super('TissueScene');
  }

  create() {
    //--------------------------------
    // Background
    //--------------------------------

    this.cameras.main.setBackgroundColor(0x0b0716);

    this.bg = this.add.graphics();

    this.drawGradient();
    this.createParticleTexture();
    this.createFlowField();
    this.frameCount = 0;
    this.fluidParticles = [];

    this.createFluid();
    this.matrixGraphics = this.add.graphics();
    this.matrixGraphics.setBlendMode(Phaser.BlendModes.ADD);
    this.matrixLines = [];

    this.createMatrix();
    this.backgroundCells = [];
    this.foregroundBlobs = [];

    this.createBackgroundCells();
    this.createForegroundBlobs();
    this.createVignette();
    //--------------------------------
    // Camera
    //--------------------------------

    this.cameraTime = 0;

    //--------------------------------
    // Fluid stirring -- dragging the mouse
    // (or a finger, touch works the same
    // way) nudges nearby fluid particles in
    // the direction of the drag. These are
    // scene-level listeners (not tied to any
    // specific interactive object), so they
    // still fire even while GameScene's own
    // cells are being dragged around on top
    // -- dragging a cell incidentally stirs
    // the backdrop too, which reads as a
    // nice bit of physicality rather than a
    // bug. Actual per-particle force is
    // applied once per frame in update().
    //--------------------------------

    this.dragActive = false;
    this.dragX = 0;
    this.dragY = 0;
    this.dragInfluenceRadius = 220;
    this.pendingDragDX = 0;
    this.pendingDragDY = 0;

    this.input.on('pointerdown', (pointer) => {
      this.dragActive = true;
      this.dragX = pointer.x;
      this.dragY = pointer.y;
      this.pendingDragDX = 0;
      this.pendingDragDY = 0;
    });

    this.input.on('pointermove', (pointer) => {
      if (!this.dragActive) return;
      this.pendingDragDX += pointer.x - this.dragX;
      this.pendingDragDY += pointer.y - this.dragY;
      this.dragX = pointer.x;
      this.dragY = pointer.y;
    });

    this.input.on('pointerup', () => {
      this.dragActive = false;
    });
    this.input.on('pointerupoutside', () => {
      this.dragActive = false;
    });
  }

  createFlowField() {
    //--------------------------------
    // No noise-field lookup table needed —
    // getFlow() below is a cheap analytic
    // curl-like function, sampled live by
    // whatever calls it. Sharing one function
    // is what makes every object's motion
    // feel like one current instead of
    // independent per-object wobble.
    //--------------------------------

    this.flowScale = 0.0016;
    this.flowSpeed = 0.00012;
  }

  getFlow(x, y, time) {
    const s = this.flowScale;
    const t = time * this.flowSpeed;

    const angle =
      Math.sin(x * s + t) * Math.cos(y * s * 1.3 - t * 0.8) * Math.PI +
      Math.sin((x + y) * s * 0.6 + t * 1.7) * 0.6;

    return {
      x: Math.cos(angle),
      y: Math.sin(angle),
    };
  }

  createVignette() {
    const g = this.add.graphics();

    g.fillStyle(0x000000, 0.18);

    g.fillRect(0, 0, GAME_WIDTH, 80);
    g.fillRect(0, GAME_HEIGHT - 80, GAME_WIDTH, 80);

    g.fillRect(0, 0, 80, GAME_HEIGHT);
    g.fillRect(GAME_WIDTH - 80, 0, 80, GAME_HEIGHT);

    g.setScrollFactor(0);
  }

  createBackgroundCells() {
    const COUNT = 180;

    for (let i = 0; i < COUNT; i++) {
      const r = Phaser.Math.Between(8, 18);

      const cell = this.add.image(
        Phaser.Math.Between(-200, GAME_WIDTH + 200),

        Phaser.Math.Between(-200, GAME_HEIGHT + 200),

        'particleDot',
      );

      cell.setTint(0xffb6df);
      cell.setAlpha(Phaser.Math.FloatBetween(0.03, 0.08));

      //--------------------------------
      // sizeScale maps the 64px shared
      // texture down to this cell's radius;
      // breathing multiplies on top of it.
      //--------------------------------

      cell.sizeScale = (r * 2) / 64;
      cell.setScale(cell.sizeScale);

      cell.speed = Phaser.Math.FloatBetween(0.03, 0.08);

      cell.seed = Math.random() * 1000;

      cell.baseScale = Phaser.Math.FloatBetween(0.8, 1.3);

      this.backgroundCells.push(cell);
    }
  }

  createForegroundBlobs() {
    const COUNT = 12;

    for (let i = 0; i < COUNT; i++) {
      const r = Phaser.Math.Between(180, 320);

      const blob = this.add.image(
        Phaser.Math.Between(-300, GAME_WIDTH + 300),

        Phaser.Math.Between(-300, GAME_HEIGHT + 300),

        'particleDot',
      );

      blob.setDisplaySize(r * 2, r * 2);
      blob.setTint(0xff88d8);
      blob.setAlpha(0.025);

      blob.speed = Phaser.Math.FloatBetween(0.02, 0.05);

      blob.seed = Math.random() * 1000;

      this.foregroundBlobs.push(blob);
    }
  }

  createMatrix() {
    const COUNT = 45;

    for (let i = 0; i < COUNT; i++) {
      const line = {
        y: Phaser.Math.Between(-100, GAME_HEIGHT + 100),

        amplitude: Phaser.Math.Between(8, 25),

        frequency: Phaser.Math.FloatBetween(0.002, 0.006),

        speed: Phaser.Math.FloatBetween(0.0004, 0.0012),

        thickness: Phaser.Math.FloatBetween(1, 3),

        alpha: Phaser.Math.FloatBetween(0.04, 0.12),

        seed: Math.random() * 1000,
      };

      this.matrixLines.push(line);
    }
  }

  drawMatrix(time) {
    const g = this.matrixGraphics;

    g.clear();

    for (const line of this.matrixLines) {
      const flow = this.getFlow(GAME_WIDTH / 2, line.y, time);
      const flowBoost = 1 + Math.abs(flow.y) * 0.6;

      g.lineStyle(
        line.thickness,

        0xffc9f8,

        line.alpha,
      );

      g.beginPath();

      for (let x = -50; x <= GAME_WIDTH + 50; x += 32) {
        const y =
          line.y +
          Math.sin(x * line.frequency + time * line.speed + line.seed) *
            line.amplitude *
            flowBoost;

        if (x == -50) {
          g.moveTo(x, y);
        } else {
          g.lineTo(x, y);
        }
      }

      g.strokePath();
    }
  }

  createFluid() {
    const COUNT = 900;

    for (let i = 0; i < COUNT; i++) {
      const r = Phaser.Math.FloatBetween(1, 4);

      const colors = [0xffffff, 0xfff4b0, 0x8ee8ff, 0xffc8ef];

      const p = this.add.image(
        Phaser.Math.Between(-100, GAME_WIDTH + 100),
        Phaser.Math.Between(-100, GAME_HEIGHT + 100),

        'particleDot',
      );

      p.setDisplaySize(r * 2, r * 2);
      p.setTint(Phaser.Utils.Array.GetRandom(colors));
      p.setAlpha(Phaser.Math.FloatBetween(0.08, 0.35));

      //--------------------------------
      // Store motion data
      //--------------------------------

      p.seed = Math.random() * 1000;

      p.speed = Phaser.Math.FloatBetween(0.15, 0.45);

      p.flow = Phaser.Math.FloatBetween(0.2, 0.8);

      p.vx = 0;
      p.vy = 0;

      p.depthFactor = Phaser.Math.FloatBetween(0.4, 1);

      p.baseAlpha = p.alpha;

      this.fluidParticles.push(p);
    }
  }

  createParticleTexture() {
    //--------------------------------
    // One shared texture for every dot-like
    // object (fluid, background cells,
    // foreground blobs). This lets WebGL
    // batch hundreds of objects into a
    // handful of draw calls instead of one
    // draw call per object.
    //--------------------------------

    const size = 64;
    const g = this.make.graphics({ add: false });

    g.fillStyle(0xffffff, 1);
    g.fillCircle(size / 2, size / 2, size / 2);

    g.generateTexture('particleDot', size, size);
    g.destroy();
  }

  drawGradient() {
    const g = this.bg;

    const cx = GAME_WIDTH / 2;
    const cy = GAME_HEIGHT / 2;

    const colors = [0x0b0716, 0x1b1030, 0x31174b, 0x58236d, 0x873d93];

    let radius = 1200;

    for (let i = 0; i < colors.length; i++) {
      g.fillStyle(colors[i], 0.25);

      g.fillCircle(cx, cy, radius);

      radius -= 180;
    }
  }

  update(time, delta) {
    this.frameCount++;

    //--------------------------------
    // Graphics re-tessellation (organic
    // blob outlines, ECM lines) is the
    // most expensive work per frame.
    // The wobble is slow enough that
    // redrawing every other frame is
    // visually indistinguishable but
    // roughly halves that cost.
    //--------------------------------

    const redrawShapes = this.frameCount % 2 === 0;

    this.cameraTime += delta * 0.00015;

    const cam = this.cameras.main;

    cam.scrollX = Math.sin(this.cameraTime) * 8;

    cam.scrollY = Math.cos(this.cameraTime * 0.7) * 6;

    cam.setZoom(1 + Math.sin(this.cameraTime * 0.8) * 0.01);

    //--------------------------------
    // Fluid Simulation
    //--------------------------------

    // Consume whatever drag movement accumulated since last frame, once,
    // so a held-but-stationary pointer applies zero force (no residual
    // push) -- only actual mouse/finger movement while held down stirs
    // the fluid.
    const dragDX = this.pendingDragDX;
    const dragDY = this.pendingDragDY;
    this.pendingDragDX = 0;
    this.pendingDragDY = 0;
    const isStirring =
      this.dragActive && (Math.abs(dragDX) > 0.01 || Math.abs(dragDY) > 0.01);
    const stirRadius = this.dragInfluenceRadius;

    for (const p of this.fluidParticles) {
      //--------------------------------
      // Shared current (flow field)
      //--------------------------------

      const flow = this.getFlow(p.x, p.y, time);

      p.x += flow.x * p.flow;
      p.y += flow.y * p.flow * 0.6;

      //--------------------------------
      // Mouse/touch stirring -- particles
      // within stirRadius of the cursor get
      // pushed along the drag direction,
      // stronger the closer they are.
      //--------------------------------

      if (isStirring) {
        const dx = p.x - this.dragX;
        const dy = p.y - this.dragY;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < stirRadius) {
          const falloff = 1 - dist / stirRadius;
          const strength = falloff * falloff * 0.5;
          p.x += dragDX * strength;
          p.y += dragDY * strength;
        }
      }

      //--------------------------------
      // True Brownian motion — a damped
      // random walk, not a periodic sine,
      // so particles never repeat a path
      //--------------------------------

      p.vx = (p.vx + (Math.random() - 0.5) * 0.06) * 0.94;
      p.vy = (p.vy + (Math.random() - 0.5) * 0.06) * 0.94;

      p.x += p.vx;
      p.y += p.vy;

      //--------------------------------
      // Twinkle
      //--------------------------------

      p.alpha = p.baseAlpha + Math.sin(time * 0.002 + p.seed) * 0.05;

      //--------------------------------
      // Wrap
      //--------------------------------

      if (p.x > GAME_WIDTH + 120) {
        p.x = -120;

        p.y = Phaser.Math.Between(
          -50,

          GAME_HEIGHT + 50,
        );
      }
    }
    if (redrawShapes) {
      this.drawMatrix(time);
    }

    //------------------------------------
    // Background Cells
    //------------------------------------

    for (const cell of this.backgroundCells) {
      cell.x += cell.speed;

      cell.y += Math.sin(time * 0.00025 + cell.seed) * 0.08;

      cell.setScale(
        cell.sizeScale *
          (cell.baseScale + Math.sin(time * 0.001 + cell.seed) * 0.05),
      );

      if (cell.x > GAME_WIDTH + 220) {
        cell.x = -220;

        cell.y = Phaser.Math.Between(-100, GAME_HEIGHT + 100);
      }
    }

    //------------------------------------
    // Foreground Tissue
    //------------------------------------

    for (const blob of this.foregroundBlobs) {
      blob.x += blob.speed;

      blob.y += Math.cos(time * 0.0002 + blob.seed) * 0.05;

      blob.alpha = 0.02 + Math.sin(time * 0.0007 + blob.seed) * 0.01;

      if (blob.x > GAME_WIDTH + 350) {
        blob.x = -350;

        blob.y = Phaser.Math.Between(-150, GAME_HEIGHT + 150);
      }
    }
  }
}

class GameScene extends Phaser.Scene {
  constructor() {
    super('GameScene');
    this.isFinished = false;
  }

  init(data) {
    this.configData =
      data && data.config
        ? ConfigManager.clone(data.config)
        : ConfigManager.getCurrentConfig();
  }

  getConfiguredPlayTime() {
    return Number(
      this.configData.totalPlayTime || this.configData.totalSurvivalTime,
    );
  }

  isTutorialLevel() {
    return this.configData && this.configData.id === 'tutorial';
  }

  createTutorialOverlay() {
    this.tutorialStepIndex = -1;
    this.tutorialPanel = this.add
      .rectangle(960, 1000, 1380, 84, 0x08162a, 0.92)
      .setStrokeStyle(3, 0x67e8f9, 0.75)
      .setDepth(DEPTHS.HUD + 10);
    this.tutorialText = this.add
      .text(960, 1000, '', {
        fontFamily: 'Arial',
        fontSize: '27px',
        color: '#e0f2fe',
        fontStyle: 'bold',
        align: 'center',
        wordWrap: { width: 1260 },
      })
      .setOrigin(0.5)
      .setDepth(DEPTHS.HUD + 11);
    this.setTutorialMessage(0);
  }

  setTutorialMessage(index) {
    if (!this.tutorialText || this.tutorialStepIndex === index) return;
    this.tutorialStepIndex = index;
    const messages = [
      'Tutorial: Drag the T-cell near the blue V cancer cell. T-cells auto-attack visible cancer.',
      'Great. Auto attack is active. Click the blue cancer cell to add bonus manual damage.',
      'Now drag the K-cell near the red H hidden cancer cell. K-cells reveal and attack hidden cancer.',
      'Excellent. Keep clicking or wait for auto attack until all cancer cells are destroyed.',
      'Tutorial complete. You learned T to V, K to H, auto attack, and click bonus damage.',
    ];
    this.tutorialText.setText(messages[index] || messages[0]);
    this.tweens.add({
      targets: [this.tutorialPanel, this.tutorialText],
      scaleX: 1.02,
      scaleY: 1.02,
      duration: 120,
      yoyo: true,
    });
  }

  updateTutorialProgress() {
    if (!this.isTutorialLevel() || !this.cellManager || this.isFinished) return;
    const visibleCancer = this.cellManager
      .getAliveCells()
      .find((c) => c.key === CELL_KEYS.V);
    const hiddenCancer = this.cellManager
      .getAliveCells()
      .find((c) => c.key === CELL_KEYS.H);
    const vHasT =
      visibleCancer &&
      visibleCancer.attachedCells &&
      Array.from(visibleCancer.attachedCells).some(
        (c) => c.key === CELL_KEYS.T && c.isAlive,
      );
    const hHasK =
      hiddenCancer &&
      hiddenCancer.attachedCells &&
      Array.from(hiddenCancer.attachedCells).some(
        (c) => c.key === CELL_KEYS.K && c.isAlive,
      );
    if (!visibleCancer && !hiddenCancer) {
      this.setTutorialMessage(4);
      this.finishGame(
        true,
        'Tutorial complete. You learned the immune response mechanics.',
      );
      return;
    }
    if (visibleCancer && !vHasT) {
      this.setTutorialMessage(0);
      return;
    }
    if (visibleCancer && vHasT) {
      this.setTutorialMessage(1);
      return;
    }
    if (!visibleCancer && hiddenCancer && !hHasK) {
      this.setTutorialMessage(2);
      return;
    }
    if (hiddenCancer && hHasK) this.setTutorialMessage(3);
  }

  create() {
    // Ambient animated backdrop, running as its own parallel scene so it
    // can keep its own camera/update loop separate from gameplay.
    // sendToBack places it behind GameScene in the render order, so the
    // play-area dish, cells, and HUD all draw on top of it.
    this.scene.launch('TissueScene');
    this.scene.sendToBack('TissueScene');
    // Cell size/color are configurable per level now, so bake (or reuse
    // an already-cached) texture set for this exact config before any
    // Cell is created -- Cell.getTextureKeyForCurrentState() reads the
    // result back off this.cellTextureKeys.
    this.cellTextureKeys = bakeAllCellTextures(this, this.configData);
    // this.createCleanBackground();
    this.elapsedTime = 0;
    this.remainingTime = this.getConfiguredPlayTime();
    this.isFinished = false;
    this.cellManager = new CellManager(this, this.configData);
    this.healthManager = new HealthManager(this, this.configData);
    this.hud = new HtmlHUD(this, this.configData);
    this.cellManager.createInitialCells();
    if (this.isTutorialLevel()) this.createTutorialOverlay();
    this.events.once(Phaser.Scenes.Events.SHUTDOWN, this.cleanUp, this);
  }

  createCleanBackground() {
    const bg = this.add.graphics();
    bg.setDepth(DEPTHS.TISSUE_BG);
    bg.fillGradientStyle(0xffffff, 0xffffff, 0xf8fbff, 0xeef6ff, 1);
    bg.fillRoundedRect(
      PLAY_AREA.x,
      PLAY_AREA.y,
      PLAY_AREA.width,
      PLAY_AREA.height,
      24,
    );
    bg.lineStyle(1, 0x94a3b8, 0.13);
    for (let x = PLAY_AREA.x + 80; x < PLAY_AREA.x + PLAY_AREA.width; x += 80) {
      bg.lineBetween(
        x,
        PLAY_AREA.y + 18,
        x,
        PLAY_AREA.y + PLAY_AREA.height - 18,
      );
    }
    for (
      let y = PLAY_AREA.y + 80;
      y < PLAY_AREA.y + PLAY_AREA.height;
      y += 80
    ) {
      bg.lineBetween(
        PLAY_AREA.x + 18,
        y,
        PLAY_AREA.x + PLAY_AREA.width - 18,
        y,
      );
    }
    bg.lineStyle(4, 0xcbd5e1, 0.85);
    bg.strokeRoundedRect(
      PLAY_AREA.x,
      PLAY_AREA.y,
      PLAY_AREA.width,
      PLAY_AREA.height,
      24,
    );
    bg.lineStyle(2, 0xffffff, 0.75);
    bg.strokeRoundedRect(
      PLAY_AREA.x + 7,
      PLAY_AREA.y + 7,
      PLAY_AREA.width - 14,
      PLAY_AREA.height - 14,
      18,
    );
  }

  update(time, delta) {
    if (this.isFinished) return;
    const dt = delta / 1000;
    this.elapsedTime += dt;
    this.remainingTime = this.getConfiguredPlayTime() - this.elapsedTime;
    this.cellManager.update(dt);
    this.healthManager.update(dt);
    this.hud.update();
    this.updateTutorialProgress();

    if (
      !this.isTutorialLevel() &&
      this.configData.winOnAllCancerDestroyed &&
      this.isAllCancerDestroyed()
    ) {
      this.finishGame(true, 'All cancer cells destroyed before time ran out.');
      return;
    }

    if (
      !this.isTutorialLevel() &&
      this.remainingTime <= 0 &&
      this.healthManager.playerHealth > this.healthManager.dangerThreshold
    )
      this.finishGame(true, 'You survived the full simulation time.');
    else if (!this.isTutorialLevel() && this.remainingTime <= 0)
      this.finishGame(
        false,
        'Time ended, but health was at or below danger threshold.',
      );
  }

  isAllCancerDestroyed() {
    const counts = this.cellManager.getCancerCounts();
    return counts.visible + counts.hidden === 0;
  }

  showFloatingText(x, y, message, color) {
    const text = this.add
      .text(x, y, message, {
        fontFamily: 'Arial',
        fontSize: '20px',
        color,
        fontStyle: 'bold',
        stroke: '#020617',
        strokeThickness: 4,
      })
      .setOrigin(0.5)
      .setDepth(DEPTHS.FLOATING_TEXT);
    this.tweens.add({
      targets: text,
      y: y - 34,
      alpha: 0,
      duration: 950,
      ease: 'Sine.easeOut',
      onComplete: () => text.destroy(),
    });
  }

  finishGame(won, reason) {
    if (this.isFinished) return;
    this.isFinished = true;
    this.time.delayedCall(500, () => {
      this.scene.start('ResultScene', {
        won,
        reason,
        config: this.configData,
        health: Math.ceil(this.healthManager.playerHealth),
        survived: Math.floor(this.elapsedTime),
      });
    });
  }

  cleanUp() {
    this.tweens.killAll();
    this.time.removeAllEvents();
    if (this.scene.isActive('TissueScene')) this.scene.stop('TissueScene');
    if (this.hud) this.hud.destroy();
    this.hud = null;
    if (this.cellManager) this.cellManager.destroy();
    this.cellManager = null;
  }
}

class ResultScene extends Phaser.Scene {
  constructor() {
    super('ResultScene');
  }
  init(data) {
    this.resultData = data || {};
  }

  create() {
    const won = !!this.resultData.won;
    this.add
      .rectangle(0, 0, GAME_WIDTH, GAME_HEIGHT, won ? 0x052e16 : 0x2a0d12)
      .setOrigin(0);
    this.add
      .rectangle(960, 520, 920, 580, 0x08162a, 0.94)
      .setStrokeStyle(4, won ? 0x86efac : 0xfca5a5);
    this.add
      .text(960, 330, won ? 'Level Complete' : 'Simulation Failed', {
        fontFamily: 'Arial',
        fontSize: '72px',
        color: won ? '#86efac' : '#fca5a5',
        fontStyle: 'bold',
      })
      .setOrigin(0.5);
    this.add
      .text(960, 420, this.resultData.reason || '', {
        fontFamily: 'Arial',
        fontSize: '28px',
        color: '#e2e8f0',
        align: 'center',
        wordWrap: { width: 760 },
      })
      .setOrigin(0.5);
    this.add
      .text(
        960,
        535,
        'Level: ' +
          (this.resultData.config ? this.resultData.config.name : 'Unknown') +
          '\nFinal Health: ' +
          (this.resultData.health || 0) +
          '\nSurvived: ' +
          (this.resultData.survived || 0) +
          ' seconds',
        {
          fontFamily: 'Arial',
          fontSize: '28px',
          color: '#cbd5e1',
          align: 'center',
          lineSpacing: 14,
        },
      )
      .setOrigin(0.5);
    this.button(780, 725, 'Restart Level', 300, 72, () =>
      this.scene.start('GameScene', {
        config: ConfigManager.getCurrentConfig(),
      }),
    );
    this.button(1140, 725, 'Configurator', 300, 72, () =>
      this.scene.start('ConfigScene'),
    );
    this.button(960, 825, 'Level Select', 300, 72, () =>
      this.scene.start('LevelSelectScene'),
    );
  }

  button(x, y, label, w, h, cb) {
    const rect = this.add
      .rectangle(x, y, w, h, 0x22c55e)
      .setStrokeStyle(3, 0xbbf7d0)
      .setInteractive({ useHandCursor: true });
    this.add
      .text(x, y, label, {
        fontFamily: 'Arial',
        fontSize: '25px',
        color: '#052e16',
        fontStyle: 'bold',
      })
      .setOrigin(0.5);
    rect.on('pointerover', () => rect.setFillStyle(0x67e8f9));
    rect.on('pointerout', () => rect.setFillStyle(0x22c55e));
    rect.on('pointerdown', cb);
  }
}

const phaserConfig = {
  type: Phaser.AUTO,
  parent: 'game-container',
  width: GAME_WIDTH,
  height: GAME_HEIGHT,
  transparent: true,
  backgroundColor: 'rgba(0,0,0,0)',
  scale: {
    mode: Phaser.Scale.FIT,
    autoCenter: Phaser.Scale.CENTER_BOTH,
    width: GAME_WIDTH,
    height: GAME_HEIGHT,
  },
  dom: { createContainer: true },
  scene: [
    BootScene,
    ConfigScene,
    LevelSelectScene,
    TissueScene,
    GameScene,
    ResultScene,
  ],
};

window.addEventListener('load', () => new Phaser.Game(phaserConfig));
