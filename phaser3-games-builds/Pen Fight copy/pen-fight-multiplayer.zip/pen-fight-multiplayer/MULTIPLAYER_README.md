# Pen Fight — Multiplayer

Real online play with custom rooms, on top of the existing single-player
game. Server-authoritative: the server owns physics, turn order, and room
state; browsers only render and send input.

## What's new

```
server/            <- plain Node scripts, no package.json, nothing to install
  server.mjs         entry point: serves the game files + the /ws endpoint
  ws-lite.mjs         hand-rolled WebSocket server (no `ws` package needed)
  PhysicsEngine.mjs   2D physics for 2-4 pens (all-pairs collision)
  TurnManager.mjs     whose turn / can-act / wait-for-settle / skips eliminated players
  RoomCode.mjs        generates short 4-character room codes
  RoomManager.mjs     routes connections to rooms (quick-join / create / join by code)
  GameRoom.mjs        one match's full state machine (lobby -> countdown -> playing -> ended)

multiplayer.html   <- new entry page for online play, with the room menu
js/net/             <- thin client: render + input only, no physics
  connection.js       shared WebSocket used by both the menu and the game
  NetGameScene.js
  NetPen.js
  main-multiplayer.js
  WinStreak.js        per-browser win-streak counter (localStorage only)

js/AudioFX.js      <- synthesized sound effects (Web Audio API, no files)
js/JuiceFX.js      <- particle bursts / trails / camera shake helpers
js/PowerUps.js     <- single-player Speed Boost / Ink Puddle pickups
```

Your original single-player game (`index.html`) is untouched and still works
exactly as before — multiplayer is a fully separate mode.

This still isn't an npm project — there's no `package.json` anywhere and
nothing to `npm install`. The server files use a `.mjs` extension, which is
what tells Node "these are ES modules" without needing a `package.json` to
declare it. Just plain scripts, run directly with `node`.

## How it works

**Menu.** Opening `multiplayer.html` shows a menu, not the game table
directly:

- **Quick Play** — drops you into an open public 2-player room, or creates
  one if none is waiting.
- **Create Room** — pick 2, 3, or 4 players, and toggle Turn Timer / Wait
  For Settle / Match Time Limit / Power-Ups / Chaos Mode / Best of 3 on or
  off. You get a short room code.
- **Join Room** — enter a 4-character code to join a friend's room.

Sharing a room is also as simple as sending a link: joining or creating a
room updates the address bar to `?room=CODE`, and opening that link
auto-joins the same room.

**Lobby = the table itself.** Once you're in a room, the game table doubles
as the lobby. Each player's pen appears in a default starting spot; drag
your own pen anywhere on the table to choose where you'll start. The server
validates every placement — it must stay fully on the table and can't
overlap another player's pen — and always confirms back, so if a spot is
rejected your pen snaps back to its last valid position.

**Auto-start.** As soon as every seat in the room is filled, there's a short
pause, then a 3-2-1 countdown, then the match begins automatically — no
"ready" button to click.

**Real pen-fight rules.** There are no walls around the table. A pen that
slides completely off the table edge eliminates that player. Turn order
automatically skips eliminated players. Last pen left on the table wins; if
the last two pens go out on the same turn, it's a draw.

**Restart.** After a match ends, restarting sends everyone back to the
lobby to reposition — not an instant replay — and the same auto-countdown
kicks in again once the room fills.

## Making it more fun

A few optional extras, all off by default except the sound/particle "juice"
below (which is always on):

**Juice.** Every collision, elimination, countdown beep, and win/draw plays
a small synthesized sound effect (no audio files — generated on the fly
with the Web Audio API) plus a particle burst, a camera shake sized to the
hit's force, and a fading trail behind fast-moving pens. This applies to
both single-player and multiplayer.

**Power-Ups** (room toggle, also available in single-player from the main
menu). Every so often a pickup appears on the table: a yellow **Speed
Boost** (⚡) that supercharges whoever's pen touches it for their very next
shot, or a dark **Ink Puddle** that slows down any pen currently sitting in
it until it fades away on its own. In multiplayer the server decides
spawns/pickups authoritatively, same as everything else.

**Chaos Mode** (room toggle). Ports single-player's simultaneous free-for-all
to multiplayer: no turn order at all, every alive player can flick their own
pen whenever they want, and the match runs on a fixed whole-match countdown
instead of ending when someone runs out of turns.

**Best of 3** (room toggle). The room plays a short series instead of a
single match — the score carries across restarts until someone wins 2, then
the next restart starts a brand new series.

**Win streak.** A small per-browser streak counter (💾 stored locally, not
by the server) shown in the multiplayer HUD and updated after every match —
purely a personal bragging-rights stat.

**Post-match stats.** The end-of-match screen shows how many shots you took
and how long the match lasted, plus the running series score when Best of 3
is on.

## Why no dependencies

I built this in a sandboxed environment with no access to the npm registry,
so I wrote a small dependency-free WebSocket server and a purpose-built 2D
physics simulation, using only what ships with Node. The physics engine
reuses your tuned constants (`PEN`, `TABLE`, `INPUT` in `js/Constants.js`)
for size/damping/friction/drag-feel, and the turn timer/settle-wait tuning
from `MATCH` in `js/GameConfig.js`.

## Running it

```bash
cd server
node server.mjs
```

Then open `http://localhost:8080` in a browser tab (or on another computer
on the same WiFi — use your machine's LAN IP instead of `localhost`, e.g.
`http://192.168.1.23:8080`). Use the menu to quick-play, create a room, or
join one by code/link. Requires Node 18+. No `npm install`, no
`package.json`, no build step.

## Testing notes

Server-side logic (room state machine, quick-join matchmaking, position
validation, turn-skip on elimination, win/draw detection, restart-to-lobby)
was verified end-to-end with scripted WebSocket clients and direct-module
tests against a running `node server.mjs` process. The client-side menu and
Phaser scene were syntax-checked and cross-referenced by hand, but this
environment has no headless browser — a real run-through in an actual
browser is worth doing once you have it open.

## Known limits (all intentional, all easy follow-ups)

- No reconnect-into-the-same-seat UI — if you refresh mid-match, you rejoin
  as a fresh connection; your old seat is freed and treated as disconnected.
- Positions snap directly from server ticks (60/sec) rather than being
  interpolated — fine on a LAN, would benefit from client-side interpolation
  over a slower/laggier connection.
- Collision/hit sound and shake intensity is calibrated from the physics
  math rather than tuned by ear (no way to play-test audio in this
  environment) — `JUICE` in `js/Constants.js` is the one place to retune it
  if hits feel too loud/quiet.
- Only one power-up is ever active on the table at a time.
- Spectator-only UI polish and matchmaking by skill/region are natural next
  steps but out of scope for this pass.
