//==================================================
// Constants.js
//==================================================

//--------------------------------------------------
// Physics scale
//--------------------------------------------------

export const SCALE = 50;

//--------------------------------------------------
// Game
//--------------------------------------------------

export const GAME = {
  WIDTH: 1280,
  HEIGHT: 720,

  // Notebook paper backdrop
  BACKGROUND: 0xfbf3df,

  FPS: 60,
};

//--------------------------------------------------
// Table
//--------------------------------------------------

export const TABLE = {
  X: 100,
  Y: 60,

  WIDTH: 1080,
  HEIGHT: 600,

  CORNER_RADIUS: 10,

  //------------------------------------------
  // Top-down wood desk look (see TableView.js)
  //------------------------------------------

  WOOD_BASE: 0xb5793f,
  WOOD_GRAIN_LIGHT: 0xc9924f,
  WOOD_GRAIN_DARK: 0x8f5c2e,

  // Thin seam marking where the table ends — not a wall, pens are
  // meant to be able to slide straight across it and off the table.
  EDGE_COLOR: 0x5c3a1e,
  EDGE_WIDTH: 3,

  SHADOW_COLOR: 0x000000,
};

//--------------------------------------------------
// Pen
//--------------------------------------------------

export const PEN = {
  LENGTH: 145,

  WIDTH: 16,

  END_RADIUS: 8,

  // Medium-weight pen
  DENSITY: 1.2,

  // Moderate table friction
  FRICTION: 0.5,

  // A little rebound on collisions, without turning into a bouncy ball
  RESTITUTION: 1,

  // Slides naturally
  LINEAR_DAMPING: 1.9,

  // Stable rotation
  ANGULAR_DAMPING: 2.2,

  // Single-player uses the first 3 (blue/green/red); multiplayer
  // rooms can go up to 4 players and add the 4th (violet).
  COLORS: [0x1e88e5, 0x43a047, 0xe53935, 0x8e24aa],

  ELIMINATION_PADDING: 6,
};
//--------------------------------------------------
// Input
//--------------------------------------------------

export const INPUT = {
  // Maximum pull distance
  MAX_DRAG_DISTANCE: 160,

  // Ignore tiny drags
  MIN_DRAG_DISTANCE: 8,

  // Base impulse (scaled by mass)
  IMPULSE_MULTIPLIER: 0.2,

  TOUCH_RADIUS: 34,

  MAX_POINTERS: 4,
};
//--------------------------------------------------
// Juice (screen shake / particles / sound) tuning — shared by both
// single-player (GameScene) and multiplayer (NetGameScene) so the
// two modes feel consistent and there's one place to retune "feel".
//--------------------------------------------------

export const JUICE = {
  // Divide a pen-on-pen relative impact speed (px/s) by this to get a
  // 0..1 "how hard was that hit" strength for sound/shake/particles.
  COLLISION_SPEED_CALIBRATION_PX: 320,

  // Below this strength, skip juice entirely (too gentle to matter).
  MIN_STRENGTH: 0.08,

  // Above this strength, also trigger a camera shake.
  SHAKE_THRESHOLD: 0.35,
};

//--------------------------------------------------
// Debug
//--------------------------------------------------

export const DEBUG = {
  ENABLED: false,

  DRAW_BODIES: true,

  DRAW_CENTERS: true,

  DRAW_SLEEPING: true,

  DRAW_CONTACTS: true,

  DRAW_VELOCITIES: true,
};
