//==================================================
// NetGameScene.js
//==================================================
// The multiplayer scene: renders whatever the server (GameRoom.mjs)
// says and forwards input. All game logic — physics, whose turn,
// lobby positioning validity, the countdown, elimination — lives on
// the server; this file owns no authority over anything.
//
// Three visual modes, driven entirely by server messages:
//   LOBBY     drag your own pen anywhere on the table to place it
//   COUNTDOWN big 3-2-1 overlay, input locked
//   PLAYING   the familiar pull-back-and-release shooting UI
//==================================================

import { GAME, PEN, INPUT, JUICE } from '../Constants.js';
import { THEME } from '../Theme.js';
import { drawTable } from '../TableView.js';
import NetPen from './NetPen.js';
import { setHandlerAndCatchUp, send } from './connection.js';
import audioFX from '../AudioFX.js';
import { burst, eliminationPuff, shake } from '../JuiceFX.js';
import { getWinStreak, recordMatchOutcome } from './WinStreak.js';

const MODE = {
  LOBBY: 'lobby',
  COUNTDOWN: 'countdown',
  PLAYING: 'playing',
};

// Squared position-delta-per-snapshot (px) above which a pen is
// considered "fast" for trail purposes. Server ticks at 60Hz, so this
// is roughly "moved noticeably even across a single tick".
const TRAIL_DELTA_SQ_THRESHOLD = 36;

export default class NetGameScene extends Phaser.Scene {
  constructor() {
    super('NetGameScene');
  }

  create() {
    this.cameras.main.setBackgroundColor(GAME.BACKGROUND);

    this.createTable();
    this.createHud();
    this.createCountdownUI();
    this.createGameOverUI();

    this.mode = MODE.LOBBY;

    this.myPlayerId = null;
    this.maxPlayers = 2;
    this.colors = PEN.COLORS;
    this.roomCode = '';
    this.config = { useTurnTimer: true, waitForSettle: true, useMatchTimeLimit: false, chaosMode: false };
    this.chaosMode = false;

    this.pens = []; // NetPen[], index-matched to server playerId
    this.lobbyPlayers = [];
    this.lastPenPositions = {}; // playerId -> {x,y}, for trail deltas
    this.powerUpView = null; // { id, container } — mirrors server's this.powerUp

    this.turnState = { currentIndex: 0, turnActive: false, waitingForSettle: false, turnTimeLeft: -1, started: false };
    this.connected = [];
    this.alive = [];
    this.gameOver = false;
    this.winner = null;

    this.aimGraphics = this.add.graphics();
    this.drag = null;

    this.input.on('pointerdown', (p) => this.onPointerDown(p));
    this.input.on('pointermove', (p) => this.onPointerMove(p));
    this.input.on('pointerup', () => this.onPointerUp());

    // main-multiplayer.js's menu handler already reacted to
    // 'room-joined' by booting this scene — anything the server sent
    // in the meantime (starting with that same 'room-joined') gets
    // replayed here before switching over to live delivery.
    setHandlerAndCatchUp((msg) => this.onServerMessage(msg));
  }

  //--------------------------------------------------
  // Table
  //--------------------------------------------------

  createTable() {
    drawTable(this);
  }

  //--------------------------------------------------
  // HUD
  //--------------------------------------------------

  createHud() {
    this.roomCodeText = this.add
      .text(16, 14, '', {
        fontFamily: THEME.FONT_BODY,
        fontSize: '20px',
        color: THEME.TEXT_MUTED,
      })
      .setInteractive({ useHandCursor: true });

    this.roomCodeText.on('pointerup', () => this.copyInviteLink());

    this.statusText = this.add
      .text(GAME.WIDTH / 2, 30, 'Connecting…', {
        fontFamily: THEME.FONT_HEADING,
        fontSize: '30px',
        color: THEME.TEXT_INK,
      })
      .setOrigin(0.5);

    this.subText = this.add
      .text(GAME.WIDTH / 2, 62, '', {
        fontFamily: THEME.FONT_BODY,
        fontSize: '20px',
        color: THEME.TEXT_MUTED,
      })
      .setOrigin(0.5);

    // Per-browser bragging-rights streak (see WinStreak.js) — a local
    // stat, not something the server tracks.
    this.streakText = this.add
      .text(GAME.WIDTH - 16, 14, '', {
        fontFamily: THEME.FONT_BODY,
        fontSize: '18px',
        color: THEME.TEXT_MUTED,
      })
      .setOrigin(1, 0);

    this.refreshStreakText();
  }

  refreshStreakText() {
    const { streak, best } = getWinStreak();

    this.streakText.setText(streak > 0 ? `🔥 Streak: ${streak} (best ${best})` : best > 0 ? `Best streak: ${best}` : '');
  }

  copyInviteLink() {
    if (!this.roomCode) return;

    const url = new URL(location.href);

    url.searchParams.set('room', this.roomCode);

    const text = url.toString();

    if (navigator.clipboard) navigator.clipboard.writeText(text).catch(() => {});

    this.roomCodeText.setText(`Room ${this.roomCode} — link copied!`);

    this.time.delayedCall(1500, () => this.updateRoomCodeText());
  }

  updateRoomCodeText() {
    if (!this.roomCode) {
      this.roomCodeText.setText('');
      return;
    }

    this.roomCodeText.setText(`Room ${this.roomCode} — tap to copy link`);
  }

  //--------------------------------------------------
  // Countdown overlay
  //--------------------------------------------------

  createCountdownUI() {
    this.countdownText = this.add
      .text(GAME.WIDTH / 2, GAME.HEIGHT / 2, '', {
        fontFamily: THEME.FONT_HEADING,
        fontSize: '160px',
        color: '#c1272d',
        stroke: THEME.TEXT_INK,
        strokeThickness: 6,
      })
      .setOrigin(0.5)
      .setDepth(9000)
      .setVisible(false);
  }

  showCountdown(value) {
    this.countdownText.setText(String(value));
    this.countdownText.setVisible(true);
    this.countdownText.setScale(1.6);
    this.countdownText.setAlpha(0);

    this.tweens.add({
      targets: this.countdownText,
      scale: 1,
      alpha: 1,
      duration: 280,
      ease: 'Back.Out',
    });
  }

  hideCountdown() {
    this.countdownText.setVisible(false);
  }

  //--------------------------------------------------
  // Game-over overlay (winner / draw + rematch)
  //--------------------------------------------------

  createGameOverUI() {
    const cx = GAME.WIDTH / 2;
    const cy = GAME.HEIGHT / 2;

    this.gameOverContainer = this.add.container(cx, cy);
    this.gameOverContainer.setDepth(10000);
    this.gameOverContainer.setVisible(false);

    const overlay = this.add.rectangle(0, 0, GAME.WIDTH, GAME.HEIGHT, 0x000000, 0.55);

    const panel = this.add.rectangle(0, 0, 440, 340, THEME.PAPER);
    panel.setStrokeStyle(5, THEME.WOOD_BROWN_DARK);

    this.gameOverTitle = this.add
      .text(0, -75, '', {
        fontFamily: THEME.FONT_HEADING,
        fontSize: '38px',
        color: THEME.TEXT_INK,
      })
      .setOrigin(0.5);

    this.gameOverSubtitle = this.add
      .text(0, -32, '', {
        fontFamily: THEME.FONT_BODY,
        fontSize: '20px',
        color: THEME.TEXT_MUTED,
      })
      .setOrigin(0.5);

    // Post-match stats (shots taken, match length) and, when the room
    // has Best of 3 on, the running series score — see
    // GameRoom.mjs's _endMatch() for where this data comes from.
    this.gameOverStats = this.add
      .text(0, 10, '', {
        fontFamily: THEME.FONT_BODY,
        fontSize: '17px',
        color: THEME.TEXT_MUTED,
        align: 'center',
        lineSpacing: 6,
      })
      .setOrigin(0.5);

    const button = this.add.container(0, 78);
    const buttonBg = this.add.rectangle(0, 0, 260, 52, THEME.INK_BLUE);

    buttonBg.setStrokeStyle(3, THEME.TEXT_INK);

    const buttonText = this.add
      .text(0, 0, 'PLAY AGAIN', {
        fontFamily: THEME.FONT_BODY,
        fontSize: '22px',
        color: THEME.TEXT_PAPER,
      })
      .setOrigin(0.5);

    button.add([buttonBg, buttonText]);
    button.setSize(260, 52);
    button.setInteractive(new Phaser.Geom.Rectangle(0, 0, 260, 52), Phaser.Geom.Rectangle.Contains);

    button.on('pointerover', () => buttonBg.setFillStyle(THEME.INK_BLUE_DARK));
    button.on('pointerout', () => buttonBg.setFillStyle(THEME.INK_BLUE));
    button.on('pointerup', () => send({ type: 'restart' }));

    this.gameOverContainer.add([overlay, panel, this.gameOverTitle, this.gameOverSubtitle, this.gameOverStats, button]);
  }

  showGameOver(result, winner, meta = {}) {
    this.gameOver = true;

    if (result === 'draw') {
      this.gameOverTitle.setText('DRAW!');
      this.gameOverTitle.setColor(THEME.TEXT_INK);
      this.gameOverSubtitle.setText('All remaining pens went off the table');
    } else {
      const youWon = winner === this.myPlayerId;

      this.gameOverTitle.setText(youWon ? 'YOU WIN!' : `PLAYER ${winner + 1} WINS!`);
      this.gameOverTitle.setColor('#c1272d');
      this.gameOverSubtitle.setText(
        this.myPlayerId === null ? 'Match over' : youWon ? 'Nicely flicked' : 'Better luck next time',
      );
    }

    this.updateGameOverStats(meta);

    // Spectators don't have a streak; only track it for an actual player.
    if (this.myPlayerId !== null) {
      const outcome = result === 'draw' ? 'draw' : winner === this.myPlayerId ? 'win' : 'loss';

      recordMatchOutcome(outcome);
      this.refreshStreakText();
    }

    this.gameOverContainer.setVisible(true);
    this.gameOverContainer.setAlpha(0);
    this.gameOverContainer.setScale(0.8);

    this.tweens.add({
      targets: this.gameOverContainer,
      alpha: 1,
      scale: 1,
      duration: 250,
      ease: 'Back.Out',
    });

    this.aimGraphics.clear();
    this.drag = null;
  }

  updateGameOverStats(meta) {
    const lines = [];

    if (meta.stats) {
      const shots = meta.stats.shots || [];
      const myShots = this.myPlayerId !== null ? shots[this.myPlayerId] : undefined;

      if (typeof myShots === 'number') {
        lines.push(`You took ${myShots} shot${myShots === 1 ? '' : 's'}`);
      }

      if (typeof meta.stats.durationMs === 'number') {
        lines.push(`Match length: ${Math.max(1, Math.round(meta.stats.durationMs / 1000))}s`);
      }
    }

    if (meta.series) {
      const scoreText = meta.series.wins.map((w, i) => `P${i + 1}: ${w}`).join('   ');

      lines.push(
        meta.series.over ? `🏆 Series won by Player ${meta.series.winner + 1}!` : `Series — ${scoreText}`,
      );
    }

    this.gameOverStats.setText(lines.join('\n'));
  }

  hideGameOver() {
    this.gameOver = false;
    this.gameOverContainer.setVisible(false);
  }

  //--------------------------------------------------
  // Server messages
  //--------------------------------------------------

  onServerMessage(msg) {
    switch (msg.type) {
      case 'room-joined':
        this.myPlayerId = msg.playerId;
        this.maxPlayers = msg.maxPlayers;
        this.colors = msg.colors;
        this.roomCode = msg.code;
        this.config = msg.config;
        this.chaosMode = !!msg.config.chaosMode;

        this.ensurePens();
        this.updateRoomCodeText();
        this.refreshHud();
        break;

      case 'lobby-state':
        this.mode = MODE.LOBBY;
        this.roomCode = msg.code;
        this.maxPlayers = msg.maxPlayers;
        this.colors = msg.colors;
        this.config = msg.config;
        this.chaosMode = !!msg.config.chaosMode;
        this.lobbyPlayers = msg.players;

        this.ensurePens();
        this.applyLobbyPositions();
        this.updateRoomCodeText();
        this.hideCountdown();
        this.hideGameOver();
        this.clearPowerUpView();
        this.refreshHud();
        break;

      case 'countdown':
        this.mode = MODE.COUNTDOWN;
        this.showCountdown(msg.value);
        audioFX.playCountdownBeep(msg.value <= 1);
        this.refreshHud();
        break;

      case 'match-start':
        this.mode = MODE.PLAYING;
        this.hideCountdown();

        this.alive = new Array(this.maxPlayers).fill(true);
        this.gameOver = false;
        this.lastPenPositions = {}; // fresh match — don't trail the lobby->start snap
        this.clearPowerUpView();

        for (const p of msg.pens) {
          const pen = this.pens[p.id];

          if (pen) {
            pen.setTransform(p.x, p.y, p.angle);
            pen.setConnected(true);
            pen.setEliminated(false);
          }
        }

        this.refreshHud();
        break;

      case 'turn-changed':
        this.turnState.currentIndex = msg.currentIndex;
        this.turnState.turnActive = true;
        this.turnState.waitingForSettle = false;
        this.highlightCurrentPen();
        this.refreshHud();
        break;

      case 'state':
        this.connected = msg.connected;

        // Chaos rooms have no TurnManager server-side, so msg.turn is
        // null there — just keep whatever stub turnState we already
        // have (nothing reads it meaningfully in chaos mode anyway).
        if (msg.turn) this.turnState = msg.turn;

        if (msg.alive) {
          this.alive = msg.alive;
          this.applyAliveState();
        }

        for (const p of msg.pens) {
          const pen = this.pens[p.id];

          if (!pen) continue;

          const prev = this.lastPenPositions[p.id];

          if (prev) {
            const dx = p.x - prev.x;
            const dy = p.y - prev.y;

            if (dx * dx + dy * dy > TRAIL_DELTA_SQ_THRESHOLD) pen.emitTrail();
          }

          this.lastPenPositions[p.id] = { x: p.x, y: p.y };

          pen.setTransform(p.x, p.y, p.angle);
        }

        if (msg.collisions && msg.collisions.length) {
          for (const c of msg.collisions) {
            const strength = Phaser.Math.Clamp(
              c.speed / JUICE.COLLISION_SPEED_CALIBRATION_PX,
              0,
              1,
            );

            if (strength < JUICE.MIN_STRENGTH) continue;

            audioFX.playCollision(strength);
            burst(this, c.x, c.y, 0xffffff, {
              count: Math.round(6 + strength * 10),
              speed: 120 + strength * 220,
            });

            if (strength > JUICE.SHAKE_THRESHOLD) shake(this, strength);
          }
        }

        this.syncPowerUpView(msg.powerUp);

        if (msg.gameOver && !this.gameOver) {
          const aliveIds = (this.alive || [])
            .map((a, i) => (a ? i : -1))
            .filter((i) => i !== -1);

          this.showGameOver(aliveIds.length === 1 ? 'win' : 'draw', aliveIds.length === 1 ? aliveIds[0] : null);
        }

        this.refreshHud();
        break;

      case 'eliminated': {
        this.alive[msg.playerId] = false;

        const pen = this.pens[msg.playerId];

        if (pen) {
          audioFX.playEliminate();
          eliminationPuff(this, pen.container.x, pen.container.y, pen.color);
          shake(this, 0.5);
        }

        this.applyAliveState();
        break;
      }

      case 'game-over':
        this.winner = msg.winner;
        this.showGameOver(msg.result, msg.winner, { stats: msg.stats, series: msg.series });
        audioFX[msg.result === 'draw' ? 'playDraw' : 'playWin']();
        this.refreshHud();
        break;

      case 'powerup-collected':
        audioFX.playPickup();
        burst(this, msg.x, msg.y, 0xffd54f, { count: 16, speed: 200 });
        break;

      case 'room-error':
        this.statusText.setText('Room error');
        this.subText.setText(msg.reason === 'not-found' ? 'That room no longer exists' : '');
        break;

      default:
        break;
    }
  }

  ensurePens() {
    if (this.pens.length === this.maxPlayers) return;

    this.pens = [];

    for (let i = 0; i < this.maxPlayers; i++) {
      const color = this.colors[i] ?? PEN.COLORS[i % PEN.COLORS.length];

      this.pens[i] = new NetPen(this, GAME.WIDTH / 2, GAME.HEIGHT / 2, color, i);
      this.pens[i].setConnected(false);
    }
  }

  applyLobbyPositions() {
    for (const p of this.lobbyPlayers) {
      const pen = this.pens[p.playerId];

      if (!pen) continue;

      // Don't fight the local player's own in-progress drag.
      const isMyActiveDrag = this.drag && this.drag.mode === 'position' && p.playerId === this.myPlayerId;

      if (!isMyActiveDrag) pen.setTransform(p.x, p.y, 0);

      pen.setConnected(p.connected);
    }
  }

  applyAliveState() {
    this.pens.forEach((pen, i) => {
      if (!pen) return;

      pen.setEliminated(!this.alive[i]);
    });
  }

  highlightCurrentPen() {
    if (this.chaosMode) {
      // No single "current" player — just highlight each connected
      // client's own pen so it's easy to spot at a glance.
      this.pens.forEach(
        (pen, i) => pen && pen.setSelected(this.mode === MODE.PLAYING && i === this.myPlayerId && this.alive[i] !== false),
      );
      return;
    }

    this.pens.forEach((pen, i) => pen && pen.setSelected(this.mode === MODE.PLAYING && i === this.turnState.currentIndex));
  }

  //--------------------------------------------------
  // Power-ups (optional, see the room's usePowerUps toggle) — purely
  // a render mirror of the server's authoritative this.powerUp; the
  // server alone decides spawn/pickup/expiry, this just keeps the
  // visual in sync with the current `state` snapshot.
  //--------------------------------------------------

  syncPowerUpView(serverPowerUp) {
    if (!serverPowerUp) {
      this.clearPowerUpView();
      return;
    }

    if (this.powerUpView && this.powerUpView.id === serverPowerUp.id) return;

    this.clearPowerUpView();

    const container = this.createPowerUpGraphics(
      serverPowerUp.kind,
      serverPowerUp.x,
      serverPowerUp.y,
      serverPowerUp.radius,
    );

    this.powerUpView = { id: serverPowerUp.id, container };
  }

  createPowerUpGraphics(kind, x, y, radius) {
    const container = this.add.container(x, y);

    container.setDepth(5);

    const g = this.add.graphics();

    if (kind === 'speed') {
      g.fillStyle(0xffd54f, 0.92);
      g.fillCircle(0, 0, radius * 0.55);
      g.lineStyle(3, 0xff8f00);
      g.strokeCircle(0, 0, radius * 0.55);

      container.add(g);

      const label = this.add.text(0, 0, '⚡', { fontSize: '26px' }).setOrigin(0.5);

      container.add(label);
    } else {
      g.fillStyle(0x2b1a12, 0.4);
      g.fillCircle(0, 0, radius);
      g.lineStyle(2, 0x1a0f0a, 0.55);
      g.strokeCircle(0, 0, radius);

      container.add(g);
    }

    this.tweens.add({
      targets: container,
      scale: { from: 0.9, to: 1.08 },
      duration: 550,
      yoyo: true,
      repeat: -1,
      ease: 'Sine.InOut',
    });

    return container;
  }

  clearPowerUpView() {
    if (this.powerUpView) {
      this.powerUpView.container.destroy();
      this.powerUpView = null;
    }
  }

  //--------------------------------------------------
  // HUD text
  //--------------------------------------------------

  refreshHud() {
    if (this.gameOver) return; // the overlay covers messaging now

    if (this.mode === MODE.LOBBY) {
      const joined = this.lobbyPlayers.filter((p) => p.connected).length;

      this.statusText.setText(`WAITING FOR PLAYERS (${joined}/${this.maxPlayers})`);
      this.subText.setText(
        this.myPlayerId === null ? 'You are spectating' : 'Drag your pen to choose a starting spot',
      );
      return;
    }

    if (this.mode === MODE.COUNTDOWN) {
      this.statusText.setText('GET READY!');
      this.subText.setText('');
      return;
    }

    if (this.pens.length) this.highlightCurrentPen();

    if (this.chaosMode) {
      this.statusText.setText('FREE FOR ALL');

      if (this.myPlayerId === null) {
        this.subText.setText('You are spectating');
      } else if (this.alive[this.myPlayerId] === false) {
        this.subText.setText('You are eliminated — watching it out');
      } else {
        this.subText.setText('Drag your pen back, then release — anytime');
      }

      return;
    }

    if (!this.turnState.started) {
      this.statusText.setText('Starting…');
      this.subText.setText('');
      return;
    }

    const isMe = this.myPlayerId === this.turnState.currentIndex;
    const label = `PLAYER ${this.turnState.currentIndex + 1}`;

    if (this.turnState.waitingForSettle) {
      this.statusText.setText(`${label} SHOT — waiting for pens to settle…`);
      this.subText.setText('');
      return;
    }

    if (this.myPlayerId === null) {
      this.statusText.setText(`${label}'s turn`);
      this.subText.setText('You are spectating');
      return;
    }

    this.statusText.setText(isMe ? 'YOUR TURN' : `${label}'s turn`);

    if (isMe && this.turnState.turnTimeLeft >= 0) {
      this.subText.setText(`${Math.ceil(this.turnState.turnTimeLeft / 1000)}s to shoot`);
    } else {
      this.subText.setText(isMe ? 'Drag your pen back, then release' : '');
    }
  }

  //--------------------------------------------------
  // Input
  //--------------------------------------------------

  canIAct() {
    if (this.gameOver || this.mode !== MODE.PLAYING || this.myPlayerId === null) return false;

    // Chaos: no turn order — anyone still alive can shoot their own
    // pen whenever they like.
    if (this.chaosMode) return this.alive[this.myPlayerId] !== false;

    return (
      this.turnState.started &&
      this.turnState.turnActive &&
      !this.turnState.waitingForSettle &&
      this.turnState.currentIndex === this.myPlayerId
    );
  }

  onPointerDown(pointer) {
    if (this.drag) return;

    if (this.mode === MODE.LOBBY) {
      if (this.myPlayerId === null) return; // spectators can't place a pen

      const pen = this.pens[this.myPlayerId];

      if (!pen) return;

      const tolerance = pointer.wasTouch ? INPUT.TOUCH_RADIUS : 0;

      if (!pen.containsPoint(pointer.worldX, pointer.worldY, tolerance)) return;

      this.drag = { mode: 'position', pen };
      return;
    }

    if (this.mode !== MODE.PLAYING) return;
    if (!this.canIAct()) return;

    const pen = this.pens[this.myPlayerId];

    if (!pen) return;

    const tolerance = pointer.wasTouch ? INPUT.TOUCH_RADIUS : 0;

    if (!pen.containsPoint(pointer.worldX, pointer.worldY, tolerance)) return;

    this.drag = {
      mode: 'shoot',
      start: { x: pointer.worldX, y: pointer.worldY },
      current: { x: pointer.worldX, y: pointer.worldY },
    };
  }

  onPointerMove(pointer) {
    if (!this.drag) return;

    if (this.drag.mode === 'position') {
      this.drag.pen.setTransform(pointer.worldX, pointer.worldY, 0);
      return;
    }

    this.drag.current.x = pointer.worldX;
    this.drag.current.y = pointer.worldY;
  }

  onPointerUp() {
    if (!this.drag) return;

    if (this.drag.mode === 'position') {
      const pen = this.drag.pen;

      this.drag = null;

      send({ type: 'set-position', x: pen.container.x, y: pen.container.y });
      return;
    }

    const { start, current } = this.drag;

    this.drag = null;
    this.aimGraphics.clear();

    const dx = start.x - current.x;
    const dy = start.y - current.y;

    if (Math.hypot(dx, dy) < INPUT.MIN_DRAG_DISTANCE) return;
    if (!this.canIAct()) return;

    send({
      type: 'shoot',
      touchX: start.x,
      touchY: start.y,
      releaseX: current.x,
      releaseY: current.y,
    });
  }

  //--------------------------------------------------
  // Update — just the aim line, everything else is event-driven
  //--------------------------------------------------

  update() {
    this.aimGraphics.clear();

    if (!this.drag || this.drag.mode !== 'shoot') return;

    const { start, current } = this.drag;

    const length = Math.hypot(current.x - start.x, current.y - start.y);

    let color = 0x00ff00;

    if (length > 60) color = 0xffff00;
    if (length > 120) color = 0xff0000;

    this.aimGraphics.lineStyle(4, color);
    this.aimGraphics.beginPath();
    this.aimGraphics.moveTo(start.x, start.y);
    this.aimGraphics.lineTo(current.x, current.y);
    this.aimGraphics.strokePath();

    this.aimGraphics.fillStyle(color);
    this.aimGraphics.fillCircle(current.x, current.y, 6);
  }
}
