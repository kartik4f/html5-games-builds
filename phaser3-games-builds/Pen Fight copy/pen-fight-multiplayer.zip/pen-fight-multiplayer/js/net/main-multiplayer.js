//==================================================
// main-multiplayer.js
//==================================================
// Wires up the pre-room HTML menu (Quick Play / Create Room / Join
// Room), then boots the Phaser game once the server confirms we're
// actually in a room. See connection.js for why the socket is opened
// here rather than inside the scene.
//==================================================

import { GAME } from '../Constants.js';
import NetGameScene from './NetGameScene.js';
import { ensureSocket, onOpen, send, setHandler } from './connection.js';

//--------------------------------------------------
// Screens
//--------------------------------------------------

const screens = {
  main: document.getElementById('screen-main'),
  create: document.getElementById('screen-create'),
  join: document.getElementById('screen-join'),
  status: document.getElementById('screen-status'),
};

function showScreen(name) {
  for (const key of Object.keys(screens)) {
    screens[key].classList.toggle('hidden', key !== name);
  }
}

function showStatus(text) {
  document.getElementById('status-text').textContent = text;
  showScreen('status');
}

//--------------------------------------------------
// Create-room panel state
//--------------------------------------------------

let maxPlayers = 2;

const playersValueEl = document.getElementById('players-value');

document.getElementById('players-minus').addEventListener('click', () => {
  maxPlayers = Math.max(2, maxPlayers - 1);
  playersValueEl.textContent = String(maxPlayers);
});

document.getElementById('players-plus').addEventListener('click', () => {
  maxPlayers = Math.min(4, maxPlayers + 1);
  playersValueEl.textContent = String(maxPlayers);
});

function wireToggle(id) {
  const btn = document.getElementById(id);

  btn.addEventListener('click', () => {
    const on = btn.dataset.on !== 'true';

    btn.dataset.on = String(on);
    btn.textContent = on ? 'ON' : 'OFF';
    btn.classList.toggle('on', on);
  });

  return () => document.getElementById(id).dataset.on === 'true';
}

const isTurnTimerOn = wireToggle('toggle-turn-timer');
const isWaitSettleOn = wireToggle('toggle-wait-settle');
const isMatchTimeOn = wireToggle('toggle-match-time');
const isPowerUpsOn = wireToggle('toggle-power-ups');
const isChaosModeOn = wireToggle('toggle-chaos-mode');
const isBestOf3On = wireToggle('toggle-best-of-3');

// Turn Timer / Wait For Settle / Match Time Limit are turn-based-only
// concepts — chaos mode runs everyone simultaneously on its own fixed
// match countdown instead, same as single-player. Hide the toggles
// that wouldn't do anything so the create-room screen doesn't lie.
document.getElementById('toggle-chaos-mode').addEventListener('click', () => {
  const chaos = isChaosModeOn();

  for (const id of ['row-turn-timer', 'row-wait-settle', 'row-match-time']) {
    document.getElementById(id).classList.toggle('hidden', chaos);
  }
});

//--------------------------------------------------
// Navigation
//--------------------------------------------------

document.getElementById('btn-quick-play').addEventListener('click', () => {
  showStatus('Finding a match…');
  ensureSocket();
  onOpen(() => send({ type: 'quick-join' }));
});

document.getElementById('btn-create-room').addEventListener('click', () => showScreen('create'));
document.getElementById('back-from-create').addEventListener('click', () => showScreen('main'));

document.getElementById('btn-join-room').addEventListener('click', () => showScreen('join'));
document.getElementById('back-from-join').addEventListener('click', () => showScreen('main'));

document.getElementById('btn-do-create').addEventListener('click', () => {
  showStatus('Creating room…');
  ensureSocket();
  onOpen(() =>
    send({
      type: 'create-room',
      maxPlayers,
      useTurnTimer: isTurnTimerOn(),
      waitForSettle: isWaitSettleOn(),
      useMatchTimeLimit: isMatchTimeOn(),
      usePowerUps: isPowerUpsOn(),
      chaosMode: isChaosModeOn(),
      bestOf3: isBestOf3On(),
    }),
  );
});

const codeInput = document.getElementById('room-code-input');
const joinErrorEl = document.getElementById('join-error');

function doJoin() {
  const code = codeInput.value.trim().toUpperCase();

  if (!code) return;

  joinErrorEl.textContent = '';
  showStatus(`Joining room ${code}…`);
  ensureSocket();
  onOpen(() => send({ type: 'join-room', code }));
}

document.getElementById('btn-do-join').addEventListener('click', doJoin);
codeInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') doJoin();
});

//--------------------------------------------------
// Server responses that happen before a room exists yet
//--------------------------------------------------

setHandler((msg) => {
  if (msg.type === 'room-joined') {
    // Reflect the code in the URL so the address bar itself becomes
    // a shareable link (?room=CODE), then hand off to the game.
    const url = new URL(location.href);

    url.searchParams.set('room', msg.code);
    history.replaceState(null, '', url);

    bootGame();
    return;
  }

  if (msg.type === 'room-error') {
    if (msg.reason === 'not-found') {
      joinErrorEl.textContent = "That room code doesn't exist.";
    } else {
      joinErrorEl.textContent = 'Could not join that room.';
    }

    showScreen('join');
  }
});

//--------------------------------------------------
// Auto-join via ?room=CODE (shareable link)
//--------------------------------------------------

const roomFromLink = new URLSearchParams(location.search).get('room');

if (roomFromLink) {
  codeInput.value = roomFromLink.toUpperCase(); // pre-filled in case the join fails and they land on the Join screen
  showStatus(`Joining room ${roomFromLink.toUpperCase()}…`);
  ensureSocket();
  onOpen(() => send({ type: 'join-room', code: roomFromLink.toUpperCase() }));
}

//--------------------------------------------------
// Boot Phaser once we're actually in a room
//--------------------------------------------------

let gameBooted = false;

function bootGame() {
  if (gameBooted) return;

  gameBooted = true;

  document.getElementById('menu-overlay').style.display = 'none';
  document.getElementById('game').style.display = 'block';

  const config = {
    type: Phaser.AUTO,

    parent: 'game',

    width: GAME.WIDTH,
    height: GAME.HEIGHT,

    backgroundColor: GAME.BACKGROUND,

    scene: [NetGameScene],

    scale: {
      parent: 'game',
      mode: Phaser.Scale.FIT,
      autoCenter: Phaser.Scale.CENTER_BOTH,

      width: GAME.WIDTH,
      height: GAME.HEIGHT,
    },

    fps: {
      target: GAME.FPS,
      forceSetTimeOut: true,
    },
  };

  new Phaser.Game(config);
}
