//==================================================
// JuiceFX.js
//==================================================
// Visual "juice" helpers shared by single-player (GameScene) and
// multiplayer (NetGameScene): collision/elimination particle bursts,
// speed trails behind fast-moving pens, and camera shake. Everything
// here is generated at runtime (a single tiny circle texture) — no
// image assets, no npm packages.
//==================================================

const DOT_TEXTURE = 'fx-dot';

function ensureDotTexture(scene) {
  if (scene.textures.exists(DOT_TEXTURE)) return;

  const g = scene.make.graphics({ x: 0, y: 0, add: false });

  g.fillStyle(0xffffff, 1);
  g.fillCircle(6, 6, 6);
  g.generateTexture(DOT_TEXTURE, 12, 12);
  g.destroy();
}

//--------------------------------------------------
// One-shot particle burst (collision spark / elimination puff)
//--------------------------------------------------

export function burst(scene, x, y, color, options = {}) {
  ensureDotTexture(scene);

  const {
    count = 14,
    speed = 220,
    life = 420,
    scale = 0.9,
    gravityY = 0,
  } = options;

  const emitter = scene.add.particles(x, y, DOT_TEXTURE, {
    speed: { min: speed * 0.3, max: speed },
    angle: { min: 0, max: 360 },
    scale: { start: scale, end: 0 },
    alpha: { start: 1, end: 0 },
    lifespan: life,
    tint: color,
    blendMode: 'ADD',
    gravityY,
    emitting: false,
  });

  emitter.explode(count, x, y);

  scene.time.delayedCall(life + 60, () => emitter.destroy());
}

// Elimination puff — a slightly larger, slower, dustier burst using
// each pen's own color plus a neutral "poof" tone.
export function eliminationPuff(scene, x, y, color) {
  burst(scene, x, y, color, { count: 10, speed: 140, life: 500, scale: 1.1 });
  burst(scene, x, y, 0xffffff, { count: 8, speed: 90, life: 400, scale: 0.7 });
}

//--------------------------------------------------
// Camera shake, scaled by an impact strength 0..1
//--------------------------------------------------

export function shake(scene, strength = 0.5) {
  const s = Phaser.Math.Clamp(strength, 0, 1);

  const duration = 120 + s * 220;
  const intensity = 0.0015 + s * 0.009;

  scene.cameras.main.shake(duration, intensity);
}

//--------------------------------------------------
// Speed trail — a small manual-emit particle emitter a pen can feed
// its position every frame while moving fast. One emitter per pen,
// created once and reused for the pen's lifetime.
//--------------------------------------------------

export class Trail {
  constructor(scene, color) {
    ensureDotTexture(scene);

    this.emitter = scene.add.particles(0, 0, DOT_TEXTURE, {
      lifespan: 260,
      speed: 0,
      scale: { start: 0.45, end: 0 },
      alpha: { start: 0.4, end: 0 },
      tint: color,
      emitting: false,
    });

    this.emitter.setDepth(-1);
  }

  emitAt(x, y) {
    this.emitter.emitParticleAt(x, y, 1);
  }

  destroy() {
    this.emitter.destroy();
  }
}

// Squared-speed threshold helpers so callers don't need to know each
// mode's velocity units — pass a 0..1 "how fast is this, relative to
// a full-power shot" ratio instead.
export const TRAIL_SPEED_RATIO_THRESHOLD = 0.35;
