//==================================================
// GameScene.js
//==================================================

import Physics from './Physics.js';
import PenManager from './PenManager.js';
import InputController from './InputController.js';
import DebugRenderer from './DebugRenderer.js';
import GameRules from './GameRules.js';
import PowerUpManager from './PowerUps.js';

import TurnTimer from './ui/TurnTimer.js';
import MatchTimer from './ui/MatchTimer.js';
import TurnIndicator from './ui/TurnIndicator.js';
import WinPopup from './ui/WinPopup.js';

import { drawTable } from './TableView.js';

import { GAME, INPUT, JUICE } from './Constants.js';
import { POWERUPS } from './GameConfig.js';
import { THEME } from './Theme.js';
import audioFX from './AudioFX.js';
import { burst, eliminationPuff, shake } from './JuiceFX.js';

export default class GameScene extends Phaser.Scene {
  constructor() {
    super('GameScene');
  }
  init() {
    window.currentScene = this;
  }

  //--------------------------------------------------
  // Create
  //--------------------------------------------------

  create() {
    //------------------------------------------
    // Background
    //------------------------------------------

    this.cameras.main.setBackgroundColor(GAME.BACKGROUND);

    this.addUIItems();

    //------------------------------------------
    // Multi-touch
    //------------------------------------------

    this.input.addPointer(INPUT.MAX_POINTERS - 1);

    //------------------------------------------
    // Physics World
    //------------------------------------------

    this.physicsWorld = new Physics();

    this.physicsWorld.onPenCollision = (penA, penB, relSpeedPx) => {
      const strength = Phaser.Math.Clamp(
        relSpeedPx / JUICE.COLLISION_SPEED_CALIBRATION_PX,
        0,
        1,
      );

      // Only bother with juice for hits with some real force behind
      // them — otherwise every gentle nudge would clack and flash.
      if (strength < JUICE.MIN_STRENGTH) return;

      const x = (penA.container.x + penB.container.x) / 2;
      const y = (penA.container.y + penB.container.y) / 2;

      audioFX.playCollision(strength);
      burst(this, x, y, 0xffffff, {
        count: Math.round(6 + strength * 10),
        speed: 120 + strength * 220,
      });

      if (strength > JUICE.SHAKE_THRESHOLD) shake(this, strength);
    };

    //------------------------------------------
    // Draw Table
    //------------------------------------------

    this.createTable();

    //------------------------------------------
    // Pen Manager
    //------------------------------------------

    this.penManager = new PenManager(
      this,

      this.physicsWorld,
    );

    this.penManager.createDefaultPens();

    // ------------------------------------------
    // Game Rules
    // -----------------------------------------
    this.gameRules = new GameRules(this, this.penManager);

    //------------------------------------------
    // Power-ups (optional, off by default — see MenuScene)
    //------------------------------------------

    this.powerUps = new PowerUpManager(this, this.penManager);
    this.powerUps.setEnabled(POWERUPS.ENABLED);

    //------------------------------------------
    // Camera
    //------------------------------------------

    // this.cameras.main.startFollow(
    //   this.penManager.getPens()[0].container,
    //   true,
    //   0.12,
    //   0.12,
    // );

    //------------------------------------------
    // Input
    //------------------------------------------

    this.inputController = new InputController(
      this,
      this.penManager,
      this.gameRules,
    );

    //------------------------------------------
    // Debug
    //------------------------------------------

    this.debugRenderer = new DebugRenderer(
      this,

      this.physicsWorld,
    );

    this.cameras.main.setZoom(1);

    this.events.on('turn-changed', (pen) => {
      /*    this.cameras.main.flash(200, 255, 255, 255);

      this.cameras.main.zoomTo(1.08, 200);

      this.time.delayedCall(200, () => {
        this.cameras.main.zoomTo(1.0, 300);
      });

      this.cameras.main.startFollow(pen.container, true, 0.12, 0.12); */
      const index = this.penManager.getPens().indexOf(pen);

      this.turnText.setText(`PLAYER ${index + 1} TURN`);
    });

    this.events.on('chaos-started', () => {
      this.turnText.setText('FREE FOR ALL');

      this.turnIndicator.hide();
    });

    this.events.on('pen-eliminated', (pen) => {
      audioFX.playEliminate();
      eliminationPuff(this, pen.container.x, pen.container.y, pen.color);
      shake(this, 0.5);
    });

    this.events.on('game-over', (result) => {
      if (result.result === 'draw') {
        audioFX.playDraw();
      } else {
        audioFX.playWin();
      }
    });

    //------------------------------------------
    // Start Match
    // (must come after all 'turn-changed' / 'chaos-started' listeners
    // above, since start() emits them synchronously)
    //------------------------------------------

    this.gameRules.start();
  }

  addUIItems() {
    this.turnText = this.add.text(GAME.WIDTH / 2, 40, 'PLAYER 1 TURN', {
      fontFamily: THEME.FONT_HEADING,
      fontSize: '30px',
      color: THEME.TEXT_INK,
    });

    this.turnText.setOrigin(0.5);
    this.turnText.setScrollFactor(0);

    this.turnTimer = new TurnTimer(this);
    this.matchTimer = new MatchTimer(this);

    this.events.on('turn-changed', () => {
      if (this.gameRules.useTurnTimer) this.turnTimer.show();

      if (this.gameRules.useMatchTimer) this.matchTimer.show();
    });

    this.events.on('chaos-started', () => {
      // Chaos has no per-turn timer, only the whole-match countdown
      if (this.gameRules.useMatchTimer) this.matchTimer.show();
    });

    this.events.on('turn-timer', (timeLeft) => {
      this.turnTimer.setTime(timeLeft, this.gameRules.turnTimeLimit);
    });

    this.events.on('match-timer', (timeLeft) => {
      this.matchTimer.setTime(timeLeft);
    });

    this.events.on('game-over', (result) => {
      this.turnTimer.hide();
      this.matchTimer.hide();
      this.turnIndicator.hide();
      this.inputController.cancel();

      this.winPopup.show(result);
    });

    this.turnIndicator = new TurnIndicator(this);
    this.events.on('turn-changed', (pen) => {
      this.turnIndicator.show(pen.playerId);
    });

    this.winPopup = new WinPopup(this);

    this.winPopup.onPlayAgain = () => {
      this.scene.restart();
    };

    this.winPopup.onMainMenu = () => {
      this.scene.start('MenuScene');
    };
  }

  //--------------------------------------------------
  // Draw Table
  //--------------------------------------------------

  createTable() {
    this.table = drawTable(this);
  }

  //--------------------------------------------------
  // Update
  //--------------------------------------------------

  update(time, delta) {
    this.delta = delta;

    //------------------------------------------
    // Physics
    //------------------------------------------

    this.physicsWorld.step();

    // ------------------------------------------
    // Game Rules
    //  ----------------------------------------
    this.gameRules.update();

    //------------------------------------------
    // Power-ups (no-op if disabled or the match is over)
    //------------------------------------------

    if (!this.gameRules.gameOver) this.powerUps.update(delta);

    //------------------------------------------
    // Pens
    //------------------------------------------

    this.penManager.update();

    //------------------------------------------
    // Input visuals
    //------------------------------------------

    this.inputController.update();

    //------------------------------------------
    // Debug overlay
    //------------------------------------------

    this.debugRenderer.update();
  }
}
