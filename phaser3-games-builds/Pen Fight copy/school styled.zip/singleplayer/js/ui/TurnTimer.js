//==================================================
// TurnTimer.js
//==================================================

import { THEME } from '../Theme.js';

export default class TurnTimer {
  constructor(scene) {
    this.scene = scene;

    //------------------------------------------
    // Container
    //------------------------------------------

    this.container = scene.add.container(scene.scale.width * 0.5, 694);

    this.container.setDepth(1000);

    //------------------------------------------
    // Background
    //------------------------------------------

    this.background = scene.add.graphics();

    this.background.fillStyle(THEME.WOOD_BROWN, 0.9);

    this.background.fillRoundedRect(-62, -24, 124, 48, 14);

    this.background.lineStyle(3, THEME.CHALK, 0.9);

    this.background.strokeRoundedRect(-62, -24, 124, 48, 14);

    //------------------------------------------
    // Text
    //------------------------------------------

    this.text = scene.add.text(0, 0, '5.0', {
      fontFamily: THEME.FONT_HEADING,
      fontSize: '28px',
      color: '#dff5e3',
    });

    this.text.setOrigin(0.5);

    //------------------------------------------

    this.container.add([this.background, this.text]);

    this.hide();
  }

  //--------------------------------------------------
  // Set Time
  //--------------------------------------------------

  setTime(milliseconds) {
    const seconds = Math.max(0, milliseconds / 1000);

    this.text.setText(seconds.toFixed(1));

    //----------------------------------
    // Color
    //----------------------------------

    if (seconds > 3) {
      this.text.setColor('#dff5e3');

      this.text.setScale(1);

      return;
    }

    if (seconds > 1) {
      this.text.setColor('#f6d989');

      this.text.setScale(1);

      return;
    }

    this.text.setColor('#f28b8b');

    const pulse = 1 + Math.sin(this.scene.time.now * 0.02) * 0.15;

    this.text.setScale(pulse);
  }

  //--------------------------------------------------
  // Show
  //--------------------------------------------------

  show() {
    this.container.setVisible(true);
  }

  //--------------------------------------------------
  // Hide
  //--------------------------------------------------

  hide() {
    this.container.setVisible(false);
  }

  //--------------------------------------------------
  // Destroy
  //--------------------------------------------------

  destroy() {
    this.container.destroy(true);
  }
}
