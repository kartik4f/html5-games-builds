//==================================================
// Pen.js
//==================================================

import { PEN } from './Constants.js';
import PhysicsUtils from './PhysicsUtils.js';

export default class Pen {
  constructor(scene, physics, x, y, color) {
    this.scene = scene;
    this.physics = physics;
    this.color = color;

    this.selected = false;

    this.createBody(x, y);
    this.createGraphics();
  }

  //--------------------------------------------------
  // Physics
  //--------------------------------------------------

  createBody(x, y) {
    this.body = this.physics.world.createDynamicBody({
      position: PhysicsUtils.worldVec(x, y),

      angle: 0,
    });

    this.body.setLinearDamping(PEN.LINEAR_DAMPING);
    this.body.setAngularDamping(PEN.ANGULAR_DAMPING);

    const halfBody = PEN.LENGTH / 2 - PEN.END_RADIUS;

    // Center rectangle

    this.body.createFixture(
      planck.Box(
        PhysicsUtils.toWorld(halfBody),

        PhysicsUtils.toWorld(PEN.WIDTH / 2),
      ),

      {
        density: PEN.DENSITY,
        friction: PEN.FRICTION,
        restitution: PEN.RESTITUTION,
      },
    );

    // Left circle

    this.body.createFixture(
      planck.Circle(
        planck.Vec2(-PhysicsUtils.toWorld(halfBody), 0),

        PhysicsUtils.toWorld(PEN.END_RADIUS),
      ),

      {
        density: PEN.DENSITY,
        friction: PEN.FRICTION,
        restitution: PEN.RESTITUTION,
      },
    );

    // Right circle

    this.body.createFixture(
      planck.Circle(
        planck.Vec2(PhysicsUtils.toWorld(halfBody), 0),

        PhysicsUtils.toWorld(PEN.END_RADIUS),
      ),

      {
        density: PEN.DENSITY,
        friction: PEN.FRICTION,
        restitution: PEN.RESTITUTION,
      },
    );
  }

  //--------------------------------------------------
  // Graphics
  //--------------------------------------------------

  createGraphics() {
    this.container = this.scene.add.container();

    this.shadow = this.scene.add.graphics();
    this.pen = this.scene.add.graphics();
    this.selection = this.scene.add.graphics();

    //---------------- Shadow ----------------

    this.shadow.fillStyle(0x000000, 0.18);

    this.shadow.fillRoundedRect(
      -PEN.LENGTH / 2 + 2,
      -PEN.WIDTH / 2 + 2,

      PEN.LENGTH,
      PEN.WIDTH,

      PEN.END_RADIUS,
    );

    //---------------- Pen ----------------

    this.drawPen();

    //---------------- Selection ----------------

    this.selection.lineStyle(3, 0xffff00);

    this.selection.strokeRoundedRect(
      -PEN.LENGTH / 2 - 5,
      -PEN.WIDTH / 2 - 5,

      PEN.LENGTH + 10,
      PEN.WIDTH + 10,

      PEN.END_RADIUS + 5,
    );

    this.selection.setVisible(false);

    this.container.add([this.shadow, this.pen, this.selection]);
  }

  //--------------------------------------------------
  // Draw Pen
  //--------------------------------------------------

  drawPen() {
    const g = this.pen;

    g.clear();

    // Barrel

    g.fillStyle(this.color);

    g.fillRoundedRect(
      -PEN.LENGTH / 2,
      -PEN.WIDTH / 2,

      PEN.LENGTH,
      PEN.WIDTH,

      PEN.END_RADIUS,
    );

    // Rear Cap

    g.fillStyle(0x222222);

    g.fillRect(
      -PEN.LENGTH / 2,
      -PEN.WIDTH / 2,

      10,
      PEN.WIDTH,
    );

    // Metallic Tip

    g.fillStyle(0xd0d0d0);

    g.fillTriangle(
      PEN.LENGTH / 2,
      -PEN.WIDTH / 2,

      PEN.LENGTH / 2,
      PEN.WIDTH / 2,

      PEN.LENGTH / 2 + 14,
      0,
    );

    // Highlight

    g.fillStyle(0xffffff, 0.3);

    g.fillRect(
      -20,
      -PEN.WIDTH / 2,

      40,
      2,
    );
  }

  //--------------------------------------------------
  // Update
  //--------------------------------------------------

  update() {
    const p = PhysicsUtils.pixelVec(this.body.getPosition());

    this.container.setPosition(p.x, p.y);

    this.container.rotation = this.body.getAngle();
    const v = this.body.getLinearVelocity();

    if (
      v.lengthSquared() < 0.0008 &&
      Math.abs(this.body.getAngularVelocity()) < 0.03
    ) {
      this.body.setLinearVelocity(planck.Vec2(0, 0));
      this.body.setAngularVelocity(0);
    }
  }

  //--------------------------------------------------
  // Shoot
  //--------------------------------------------------

  shoot(localPoint, impulse) {
    const worldPoint = this.body.getWorldPoint(localPoint);

    this.body.applyLinearImpulse(
      planck.Vec2(impulse.x, impulse.y),

      worldPoint,

      true,
    );
  }

  //--------------------------------------------------
  // Selection
  //--------------------------------------------------

  setSelected(selected) {
    this.selected = selected;

    this.selection.setVisible(selected);
  }

  //--------------------------------------------------
  // Helpers
  //--------------------------------------------------

  containsPoint(x, y) {
    return PhysicsUtils.bodyContainsPoint(
      this.body,

      x,

      y,
    );
  }

  getLocalPoint(x, y) {
    return this.body.getLocalPoint(PhysicsUtils.worldVec(x, y));
  }

  isMoving() {
    return PhysicsUtils.isBodyMoving(this.body);
  }

  //--------------------------------------------------
  // Reset
  //--------------------------------------------------

  reset(x, y, angle = 0) {
    this.body.setTransform(
      PhysicsUtils.worldVec(x, y),

      angle,
    );

    this.body.setLinearVelocity(planck.Vec2(0, 0));

    this.body.setAngularVelocity(0);

    this.body.setAwake(true);

    this.update();
  }

  //--------------------------------------------------
  // Shoot
  //--------------------------------------------------

  shoot(localPoint, impulse) {
    const worldPoint = this.body.getWorldPoint(localPoint);

    this.body.applyLinearImpulse(
      planck.Vec2(impulse.x, impulse.y),

      worldPoint,

      true,
    );
  }

  //--------------------------------------------------
  // Destroy
  //--------------------------------------------------

  destroy() {
    this.physics.world.destroyBody(this.body);

    this.container.destroy(true);
  }
}

/* 
Pen should have two completely separate responsibilities:
Pen
│
├── Physics Body (Planck)
│
└── Visual Container (Phaser)
       │
       ├── Shadow
       ├── Barrel
       ├── Tip
       ├── Cap
       ├── Selection Ring
       └── Debug Layer */
