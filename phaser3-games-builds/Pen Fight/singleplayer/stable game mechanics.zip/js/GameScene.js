//==================================================
// GameScene.js
//==================================================

import Physics from './Physics.js';
import PenManager from './PenManager.js';
import InputController from './InputController.js';
import DebugRenderer from './DebugRenderer.js';

import { GAME, TABLE, INPUT } from './Constants.js';

export default class GameScene extends Phaser.Scene {
  constructor() {
    super('GameScene');
  }

  //--------------------------------------------------
  // Create
  //--------------------------------------------------

  create() {
    //------------------------------------------
    // Background
    //------------------------------------------

    this.cameras.main.setBackgroundColor(GAME.BACKGROUND);

    //------------------------------------------
    // Multi-touch
    //------------------------------------------

    this.input.addPointer(INPUT.MAX_POINTERS - 1);

    //------------------------------------------
    // Physics World
    //------------------------------------------

    this.physicsWorld = new Physics();

    //------------------------------------------
    // Draw Table
    //------------------------------------------

    this.createTable();

    //------------------------------------------
    // Pen Manager
    //------------------------------------------

    this.penManager = new PenManager(
      this,

      this.physicsWorld,
    );

    this.penManager.createDefaultPens();

    //------------------------------------------
    // Input
    //------------------------------------------

    this.inputController = new InputController(
      this,

      this.penManager,
    );

    //------------------------------------------
    // Debug
    //------------------------------------------

    this.debugRenderer = new DebugRenderer(
      this,

      this.physicsWorld,
    );
  }

  //--------------------------------------------------
  // Draw Table
  //--------------------------------------------------

  createTable() {
    const g = this.add.graphics();

    g.fillStyle(TABLE.COLOR);

    g.fillRoundedRect(
      TABLE.X,
      TABLE.Y,

      TABLE.WIDTH,
      TABLE.HEIGHT,

      TABLE.CORNER_RADIUS,
    );

    g.lineStyle(
      TABLE.BORDER,

      TABLE.BORDER_COLOR,
    );

    g.strokeRoundedRect(
      TABLE.X,
      TABLE.Y,

      TABLE.WIDTH,
      TABLE.HEIGHT,

      TABLE.CORNER_RADIUS,
    );

    g.setDepth(-100);

    this.table = g;
  }

  //--------------------------------------------------
  // Update
  //--------------------------------------------------

  update(time, delta) {
    this.delta = delta;

    //------------------------------------------
    // Physics
    //------------------------------------------

    this.physicsWorld.step();

    //------------------------------------------
    // Pens
    //------------------------------------------

    this.penManager.update();

    //------------------------------------------
    // Input visuals
    //------------------------------------------

    this.inputController.update();

    //------------------------------------------
    // Debug overlay
    //------------------------------------------

    this.debugRenderer.update();
  }
}
