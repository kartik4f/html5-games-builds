//==================================================
// MenuScene.js
//==================================================

import { GAME } from './Constants.js';
import { MATCH, GAME_MODE } from './GameConfig.js';

const CHAOS_MATCH_SECONDS = Math.round(MATCH.CHAOS_MATCH_TIME / 1000);

export default class MenuScene extends Phaser.Scene {
  constructor() {
    super('MenuScene');
  }

  //--------------------------------------------------
  // Create
  //--------------------------------------------------

  create() {
    this.cameras.main.setBackgroundColor(GAME.BACKGROUND);

    // Local draft of the settings — only written back to MATCH on Start
    this.draft = {
      mode: MATCH.MODE,
      useTurnTimer: MATCH.USE_TURN_TIMER,
      waitForSettle: MATCH.WAIT_FOR_SETTLE,
      useMatchTimeLimit: MATCH.USE_MATCH_TIME_LIMIT,
    };

    this.buildTitle();
    this.buildModeButtons();
    this.buildToggles();
    this.buildChaosInfo();
    this.buildStartButton();

    this.refreshUI();
  }

  //--------------------------------------------------
  // Title
  //--------------------------------------------------

  buildTitle() {
    this.add
      .text(GAME.WIDTH / 2, 90, 'PEN FIGHT', {
        fontFamily: 'Arial',
        fontSize: '64px',
        fontStyle: 'bold',
        color: '#ffffff',
      })
      .setOrigin(0.5);

    this.add
      .text(GAME.WIDTH / 2, 150, 'Select Game Mode', {
        fontFamily: 'Arial',
        fontSize: '24px',
        color: '#cccccc',
      })
      .setOrigin(0.5);
  }

  //--------------------------------------------------
  // Mode Buttons
  //--------------------------------------------------

  buildModeButtons() {
    const centerX = GAME.WIDTH / 2;

    this.turnBasedButton = this.createButton(
      centerX - 170,
      240,
      300,
      80,
      'TURN-BASED',
      () => this.setMode(GAME_MODE.TURN_BASED),
    );

    this.chaosButton = this.createButton(
      centerX + 170,
      240,
      300,
      80,
      'CHAOS',
      () => this.setMode(GAME_MODE.CHAOS),
    );
  }

  setMode(mode) {
    this.draft.mode = mode;

    this.refreshUI();
  }

  //--------------------------------------------------
  // Option Toggles
  //--------------------------------------------------

  buildToggles() {
    const centerX = GAME.WIDTH / 2;

    this.timerToggle = this.createToggle(centerX, 370, 'TURN TIMER', () => {
      this.draft.useTurnTimer = !this.draft.useTurnTimer;

      this.refreshUI();
    });

    this.settleToggle = this.createToggle(
      centerX,
      450,
      'WAIT FOR SETTLE',
      () => {
        this.draft.waitForSettle = !this.draft.waitForSettle;

        this.refreshUI();
      },
    );

    this.matchTimeToggle = this.createToggle(
      centerX,
      530,
      'MATCH TIME LIMIT',
      () => {
        this.draft.useMatchTimeLimit = !this.draft.useMatchTimeLimit;

        this.refreshUI();
      },
    );
  }

  //--------------------------------------------------
  // Chaos Mode Info
  // (chaos has no turn timer toggle — it always runs on a fixed
  // whole-match countdown instead, since there's no turn order to
  // otherwise bring the match to an end)
  //--------------------------------------------------

  buildChaosInfo() {
    this.chaosInfoText = this.add
      .text(GAME.WIDTH / 2, 370, `MATCH ENDS AFTER ${CHAOS_MATCH_SECONDS}s`, {
        fontFamily: 'Arial',
        fontSize: '22px',
        color: '#cccccc',
      })
      .setOrigin(0.5);
  }

  //--------------------------------------------------
  // Start Button
  //--------------------------------------------------

  buildStartButton() {
    this.createButton(
      GAME.WIDTH / 2,
      650,
      280,
      90,
      'START',
      () => this.startGame(),
      0x2e7d32,
      0x388e3c,
    );
  }

  startGame() {
    const isTurnBased = this.draft.mode === GAME_MODE.TURN_BASED;

    MATCH.MODE = this.draft.mode;
    MATCH.USE_TURN_TIMER = this.draft.useTurnTimer;

    // Chaos mode never waits for settling — there's no turn to hand off
    MATCH.WAIT_FOR_SETTLE = isTurnBased ? this.draft.waitForSettle : false;

    // Chaos mode always runs its own fixed match countdown regardless
    MATCH.USE_MATCH_TIME_LIMIT = isTurnBased
      ? this.draft.useMatchTimeLimit
      : false;

    this.scene.start('GameScene');
  }

  //--------------------------------------------------
  // UI State
  //--------------------------------------------------

  refreshUI() {
    const isTurnBased = this.draft.mode === GAME_MODE.TURN_BASED;

    this.setButtonActive(this.turnBasedButton, isTurnBased);
    this.setButtonActive(this.chaosButton, !isTurnBased);

    // Turn timer, wait-for-settle & match time limit are turn-based-only
    // concepts. Chaos always runs on its own fixed match countdown instead.
    this.timerToggle.setVisible(isTurnBased);
    this.settleToggle.setVisible(isTurnBased);
    this.matchTimeToggle.setVisible(isTurnBased);
    this.chaosInfoText.setVisible(!isTurnBased);

    if (isTurnBased) {
      this.setToggleState(this.timerToggle, this.draft.useTurnTimer);
      this.setToggleState(this.settleToggle, this.draft.waitForSettle);
      this.setToggleState(this.matchTimeToggle, this.draft.useMatchTimeLimit);
    }
  }

  setButtonActive(container, active) {
    container.bg.setFillStyle(active ? 0x1976d2 : 0x333333);
  }

  setToggleState(container, on) {
    container.bg.setFillStyle(on ? 0x2e7d32 : 0x555555);

    container.label.setText(`${container.baseLabel}: ${on ? 'ON' : 'OFF'}`);
  }

  //--------------------------------------------------
  // Button Factory
  //--------------------------------------------------

  createButton(x, y, w, h, label, onClick, color = 0x333333, hoverColor) {
    const container = this.add.container(x, y);

    const bg = this.add.rectangle(0, 0, w, h, color);

    bg.setStrokeStyle(3, 0xffffff);

    const text = this.add
      .text(0, 0, label, {
        fontFamily: 'Arial',
        fontSize: '24px',
        fontStyle: 'bold',
        color: '#ffffff',
      })
      .setOrigin(0.5);

    container.add([bg, text]);

    container.setSize(w, h);

    container.setInteractive(
      new Phaser.Geom.Rectangle(0, 0, w, h),
      Phaser.Geom.Rectangle.Contains,
    );

    // Only static buttons (no other dynamic color state) get a hover
    // swap — mode/toggle buttons already show state via refreshUI(),
    // and a naive hover-out would stomp that color.
    if (hoverColor) {
      container.on('pointerover', () => bg.setFillStyle(hoverColor));
      container.on('pointerout', () => bg.setFillStyle(color));
    }

    container.on('pointerup', onClick);

    container.bg = bg;
    container.label = text;

    return container;
  }

  //--------------------------------------------------
  // Toggle Factory
  //--------------------------------------------------

  createToggle(x, y, label, onClick) {
    const container = this.createButton(
      x,
      y,
      360,
      64,
      `${label}: OFF`,
      onClick,
    );

    container.baseLabel = label;

    return container;
  }
}
