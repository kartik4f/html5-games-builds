//==================================================
// MatchTimer.js
//==================================================
// Whole-match countdown (chaos: always on; turn-based: optional via
// GameConfig.USE_MATCH_TIME_LIMIT). Kept visually distinct from
// TurnTimer since both can be on screen at once in turn-based mode.
//==================================================

export default class MatchTimer {
  constructor(scene) {
    this.scene = scene;

    //------------------------------------------
    // Container
    //------------------------------------------

    this.container = scene.add.container(scene.scale.width - 90, 50);

    this.container.setDepth(1000);

    //------------------------------------------
    // Background
    //------------------------------------------

    this.background = scene.add.graphics();

    this.background.fillStyle(0x000000, 0.45);

    this.background.fillRoundedRect(-70, -34, 140, 68, 12);

    //------------------------------------------
    // Label
    //------------------------------------------

    this.label = scene.add.text(0, -16, 'MATCH', {
      fontFamily: 'Arial',
      fontSize: '14px',
      fontStyle: 'bold',
      color: '#aaaaaa',
    });

    this.label.setOrigin(0.5);

    //------------------------------------------
    // Text
    //------------------------------------------

    this.text = scene.add.text(0, 12, '0:60', {
      fontFamily: 'Arial',
      fontSize: '26px',
      fontStyle: 'bold',
      color: '#00e5ff',
    });

    this.text.setOrigin(0.5);

    //------------------------------------------

    this.container.add([this.background, this.label, this.text]);

    this.hide();
  }

  //--------------------------------------------------
  // Set Time
  //--------------------------------------------------

  setTime(milliseconds) {
    const totalSeconds = Math.max(0, Math.ceil(milliseconds / 1000));

    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;

    this.text.setText(`${minutes}:${seconds.toString().padStart(2, '0')}`);

    //----------------------------------
    // Color
    //----------------------------------

    if (totalSeconds > 10) {
      this.text.setColor('#00e5ff');
    } else if (totalSeconds > 5) {
      this.text.setColor('#ffff00');
    } else {
      this.text.setColor('#ff4040');
    }
  }

  //--------------------------------------------------
  // Show
  //--------------------------------------------------

  show() {
    this.container.setVisible(true);
  }

  //--------------------------------------------------
  // Hide
  //--------------------------------------------------

  hide() {
    this.container.setVisible(false);
  }

  //--------------------------------------------------
  // Destroy
  //--------------------------------------------------

  destroy() {
    this.container.destroy(true);
  }
}
