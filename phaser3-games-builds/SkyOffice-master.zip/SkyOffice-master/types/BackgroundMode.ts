export enum BackgroundMode {
  DAY,
  NIGHT,
}
