export enum PlayerBehavior {
  IDLE,
  SITTING,
}
