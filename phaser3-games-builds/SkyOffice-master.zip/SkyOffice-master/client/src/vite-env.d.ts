/// <reference types="vite/client" />

declare module '*.png'
