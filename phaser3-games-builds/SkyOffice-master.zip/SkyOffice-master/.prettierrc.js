module.exports = {
  printWidth: 100,
  singleQuote: true,
  trailingComma: 'es5',
  semi: false,
  tabWidth: 2,
  bracketSpacing: true,
  jsxBracketSameLine: false,
}
